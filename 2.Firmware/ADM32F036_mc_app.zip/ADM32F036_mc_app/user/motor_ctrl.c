#include "motor_ctrl.h"
#include "utils.h"

motor_ctrl_t motor_ctrl = {
    .state = INIT,    
};

#pragma CODE_SECTION(MC_controlword_update, "ramfuncs");
int MC_controlword_update(void)
{
    switch(ODObjs.control_word & 0x00FF)
    {
        case CW_CMD_OPERATION_ENABLE: // ʹ�ܵ��
        {
            if(RunSignal == 0)
            {
                RunSignal = 1;
            }
            break;
        }
        case CW_CMD_OPERATION_DISABLE: // ʧ�ܵ��
        {
            if(RunSignal == 1)
            {
                RunSignal = 0;
            }
            break;
        }
        case CW_CMD_RESET_HOME: // ��λԭ��
        {

            break;
        }
        case CW_CMD_ERROR_RESET: // �������
        {
            ODObjs.error_code = 0;
            break;
        }
        case CW_CMD_DEV_ENCODER_CALIB: // ������У׼
        {
            motor_ctrl.state = ENCODER_CALIBRATE;
            break;
        }
        default:
        {
            break;
        }
    }
    ODObjs.control_word &= 0xFF00;
    return 0;
}

/**
 * @brief ���״̬������ѭ��
 * @note ����stimer�����2Khzѭ��ִ��
 */
#pragma CODE_SECTION(MC_servo_loop, "ramfuncs");
void MC_servo_loop(void)
{
    // ���¼��ٶ�λ�ú��ٶ�
    // encoder.degree_q14 = (encoder.enc_turns / GEAR_RATIO * 2pi * 2^14) + ((encoder.enc_degree_lined - �ϵ�ʱ�����������ĽǶ�ֵ) / ENCODER_CPR / GEAR_RATIO * 2pi * 2^14) + (encoder.error * 0.75f * 2pi * 16384 / 8192) ;
    encoder.degree_q14 = (encoder.enc_turns * 8580) + (((int32_t)((int32_t)encoder.enc_degree_lined - (int32_t)encoder.in_enc_deg_zero) * 8580) >> 14) + (int32_t)((float)encoder.error * 9.245f);
    encoder.velocity_q14 = (int32_t)(encoder.enc_velocity_q14 * GEAR_RATIO_INV);
    
    switch(motor_ctrl.state)
    {
        case INIT:
        {
            motor_ctrl.state = MIT;
            break;
        }
        case MIT:
        {
            int64_t degree_err_q14 = motor_ctrl.degree_ref_q14 - encoder.degree_q14;
            int64_t velocity_err_q14 = motor_ctrl.velocity_ref_q14 - encoder.velocity_q14;

            degree_err_q14   = CLAMP(degree_err_q14,  -163840,  163840); // ���λ��Ŀ��ֵ��ʵ��ֵ�����¼����м����������·���ת��������
            velocity_err_q14 = CLAMP(velocity_err_q14,-1638400, 1638400);

            int32_t out_q14 = 0;

            out_q14 = (int32_t)(((int64_t)motor_ctrl.Kp_q14 * degree_err_q14) >> 14) \
                    + (int32_t)(((int64_t)motor_ctrl.Kd_q14 * velocity_err_q14) >> 14) \
                    + (int32_t)((int64_t)motor_ctrl.current_ref_q14 * 40960 / MOTOR_RATED_CUR);

            out_q14 = CLAMP(out_q14, -67108864, 67108864); // 4096 * 16384
            
            Iq = out_q14 >> 14; 
            Id = 0;
            break;
        }
        case ENCODER_CALIBRATE: 
        {
            if(encoder_calibrate() == 1)
            {
                motor_ctrl.state = MIT;
            }
            break;
        }
        case ENCODER_ZERO: 
        {

            break;
        }
        case SOFT_STOP:
        {
            static int32_t Iq_init = 0;
            static int32_t Id_init = 0;
            static uint16_t ramp_count = 0;
            static uint16_t  ramp_flag = 0;
            
            #define RAMP_STEPS 4000 
            
            if(ramp_flag == 0)
            {
                ramp_flag = 1;
                ramp_count = 0;
                Iq_init = Iq;
                Id_init = Id;
            }
            if(ramp_count < RAMP_STEPS)
            {
                ramp_count++;
                
                // I = I_init �� (STEPS - count) / STEPS
                Iq = (int16_t)((Iq_init * (int32_t)(RAMP_STEPS - ramp_count)) / RAMP_STEPS);
                Id = (int16_t)((Id_init * (int32_t)(RAMP_STEPS - ramp_count)) / RAMP_STEPS);
            }
            else
            {
                Iq = 0;
                Id = 0;
                ramp_flag = 0;
                RunSignal = 0; // ������ʹ��λ
                motor_ctrl.state = STOPPED;
            }
            
            break;
        }
        case STOPPED:
        {
            break;
        }
        default :
        {
            break;
        }
    }
}

/**
 * @brief ��λ����
 * @param err ��������
 */
void set_err(tErrorCode err)
{
    if(ODObjs.error_code & err) // ��ǰ�����Ѵ���
    {
        return; 
    }
    else
    {
        ODObjs.error_code |= err; // ��λ�ô���
    }
}

/**
 * @brief �������
 * @param err ��������
 */
void clr_err(tErrorCode err)
{
    if(ODObjs.error_code & err) // ��ǰ�����Ѵ���
    {
        ODObjs.error_code &= ~err; // ����ô���
    }
}

float board_temp;
float motor_temp;

#define ADC_MAX 4095.0f
#define R_PULLUP 4700.0f   // 4.7k
#define R25   10000.0f
#define BETA  3445.0f

/**
 * @brief �ɼ���������������
 * @note ����stimer�����100hzѭ��ִ��
 */
void info_collect_loop(void)
{
    // static uint16_t cnt = 0;
    // if(cnt%2 == 0)
    // {
    //     Iq = 0;
    //     Id = 1000;
    // }
    // else
    // {
    //     Iq = 0;
    //     Id = 0;
    // }
    // cnt++;

    static float r_ntc;
    static float board_temp_filt = 0.0f;
    static float motor_temp_filt = 0.0f;
    const float alpha = 0.01f; // �˲�ϵ����ԽСԽƽ����0~1

    // �ɼ��������¶�
    r_ntc = 4700.0f * ADC_NTC_M / (4095.0f - ADC_NTC_M);
    float board_temp_raw = 1.0f / (1.0f / 298.15f + logf(r_ntc / 10000.0f) / 3445.0f) - 273.15f;
    // һ�׵�ͨ�˲�
    board_temp_filt = board_temp_filt + alpha * (board_temp_raw - board_temp_filt);
    board_temp = board_temp_filt;

    // �ɼ�����¶�
    r_ntc = 4700.0f * ADC_NTC / (4095.0f - ADC_NTC);
    float motor_temp_raw = 1.0f / (1.0f / 298.15f + logf(r_ntc / 10000.0f) / 3445.0f) - 273.15f;
    // һ�׵�ͨ�˲�
    motor_temp_filt = motor_temp_filt + alpha * (motor_temp_raw - motor_temp_filt);
    motor_temp = motor_temp_filt;

    // ���ǵ�ʵ�ʵ��ڹ��ϵĳ������������ȴ����¶ȱ���Ȼ��ϵ��������������ֻ��һ���򵥵ĳ��´����ϱ������رյ����̵Ķ������̣����漰�¶Ƚ����Զ������Ĺ���
    if (!(ODObjs.error_code & ERR_OVER_TEMP_MOTOR))
    {
        if (motor_temp > MOTOR_TEMP_MAX)
        {
            set_err(ERR_OVER_TEMP_MOTOR);
            motor_ctrl.state = SOFT_STOP;
        }
    }
    else
    {
        if (motor_temp < MOTOR_TEMP_RECOVER)
        {
            clr_err(ERR_OVER_TEMP_MOTOR);
        }
    }
    if (!(ODObjs.error_code & ERR_OVER_TEMP_DRV)) 
    {
        if (board_temp > BOARD_TEMP_MAX)
        {
            set_err(ERR_OVER_TEMP_DRV);
            motor_ctrl.state = SOFT_STOP;
        }
    }
    else
    {
        if (board_temp < BOARD_TEMP_RECOVER)
        {
            clr_err(ERR_OVER_TEMP_DRV);
        }
    }
}
