ADM32F036A3DEMO.out -b -image -memwidth 16 -romwidth 16 -o ADM32F036A3DEMO.bin ROMS { FLASH: origin = 0x008000, length = 0x008000, romwidth = 16, fill = 0xFFFF }  
