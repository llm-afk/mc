################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
LIB_SRCS += \
../user/ADP32F036_027_Flash_API_ZONE.lib 

C_SRCS += \
../user/Flash_EEPROM.c \
../user/canfd.c \
../user/encoder.c \
../user/iap.c \
../user/led.c \
../user/lpg.c \
../user/motor_ctrl.c \
../user/od.c \
../user/ringbuffer.c \
../user/stimer.c \
../user/utils.c 

C_DEPS += \
./user/Flash_EEPROM.d \
./user/canfd.d \
./user/encoder.d \
./user/iap.d \
./user/led.d \
./user/lpg.d \
./user/motor_ctrl.d \
./user/od.d \
./user/ringbuffer.d \
./user/stimer.d \
./user/utils.d 

OBJS += \
./user/Flash_EEPROM.obj \
./user/canfd.obj \
./user/encoder.obj \
./user/iap.obj \
./user/led.obj \
./user/lpg.obj \
./user/motor_ctrl.obj \
./user/od.obj \
./user/ringbuffer.obj \
./user/stimer.obj \
./user/utils.obj 

OBJS__QUOTED += \
"user\Flash_EEPROM.obj" \
"user\canfd.obj" \
"user\encoder.obj" \
"user\iap.obj" \
"user\led.obj" \
"user\lpg.obj" \
"user\motor_ctrl.obj" \
"user\od.obj" \
"user\ringbuffer.obj" \
"user\stimer.obj" \
"user\utils.obj" 

C_DEPS__QUOTED += \
"user\Flash_EEPROM.d" \
"user\canfd.d" \
"user\encoder.d" \
"user\iap.d" \
"user\led.d" \
"user\lpg.d" \
"user\motor_ctrl.d" \
"user\od.d" \
"user\ringbuffer.d" \
"user\stimer.d" \
"user\utils.d" 

C_SRCS__QUOTED += \
"../user/Flash_EEPROM.c" \
"../user/canfd.c" \
"../user/encoder.c" \
"../user/iap.c" \
"../user/led.c" \
"../user/lpg.c" \
"../user/motor_ctrl.c" \
"../user/od.c" \
"../user/ringbuffer.c" \
"../user/stimer.c" \
"../user/utils.c" 


