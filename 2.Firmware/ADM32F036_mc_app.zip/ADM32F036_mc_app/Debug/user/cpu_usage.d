# FIXED

user/cpu_usage.obj: ../user/cpu_usage.c
user/cpu_usage.obj: ../user/cpu_usage.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h
user/cpu_usage.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h
user/cpu_usage.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h

../user/cpu_usage.c:

../user/cpu_usage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h:

