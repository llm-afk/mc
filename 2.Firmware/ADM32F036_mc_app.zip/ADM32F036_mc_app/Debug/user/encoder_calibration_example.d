# FIXED

user/encoder_calibration_example.obj: ../user/encoder_calibration_example.c
user/encoder_calibration_example.obj: ../user/encoder.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MainInclude.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Define.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/SPIcomm.h
user/encoder_calibration_example.obj: ../user/motor_ctrl.h
user/encoder_calibration_example.obj: ../user/encoder.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MotorInclude.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Parameter.h
user/encoder_calibration_example.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/SubPrgInclude.h
user/encoder_calibration_example.obj: ../user/od.h
user/encoder_calibration_example.obj: ../user/canfd.h
user/encoder_calibration_example.obj: ../user/ringbuffer.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlib.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlibf.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h
user/encoder_calibration_example.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h
user/encoder_calibration_example.obj: ../user/iap.h
user/encoder_calibration_example.obj: ../user/flash_eeprom.h
user/encoder_calibration_example.obj: ../user/Flash_ADP32F03x_API_Library.h
user/encoder_calibration_example.obj: ../user/Flash_ADP32F03x_API_Config.h
user/encoder_calibration_example.obj: ../user/mm.h

../user/encoder_calibration_example.c:

../user/encoder.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Define.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/SPIcomm.h:

../user/motor_ctrl.h:

../user/encoder.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Parameter.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/SubPrgInclude.h:

../user/od.h:

../user/canfd.h:

../user/ringbuffer.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlib.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlibf.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h:

../user/iap.h:

../user/flash_eeprom.h:

../user/Flash_ADP32F03x_API_Library.h:

../user/Flash_ADP32F03x_API_Config.h:

../user/mm.h:

