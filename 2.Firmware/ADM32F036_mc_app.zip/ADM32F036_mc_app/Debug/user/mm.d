# FIXED

user/mm.obj: ../user/mm.c
user/mm.obj: ../user/mm.h

../user/mm.c:

../user/mm.h:

