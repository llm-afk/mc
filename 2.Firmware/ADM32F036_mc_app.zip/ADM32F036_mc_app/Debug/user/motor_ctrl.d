# FIXED

user/motor_ctrl.obj: ../user/motor_ctrl.c
user/motor_ctrl.obj: ../user/motor_ctrl.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
user/motor_ctrl.obj: ../user/encoder.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SPIcomm.h
user/motor_ctrl.obj: ../user/motor_ctrl.h
user/motor_ctrl.obj: ../user/utils.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h
user/motor_ctrl.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h
user/motor_ctrl.obj: ../user/od.h
user/motor_ctrl.obj: ../user/canfd.h
user/motor_ctrl.obj: ../user/ringbuffer.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlib.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlibf.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h
user/motor_ctrl.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h
user/motor_ctrl.obj: ../user/iap.h
user/motor_ctrl.obj: ../user/flash_eeprom.h
user/motor_ctrl.obj: ../user/Flash_ADP32F03x_API_Library.h
user/motor_ctrl.obj: ../user/Flash_ADP32F03x_API_Config.h
user/motor_ctrl.obj: ../user/mm.h

../user/motor_ctrl.c:

../user/motor_ctrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

../user/encoder.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SPIcomm.h:

../user/motor_ctrl.h:

../user/utils.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h:

../user/od.h:

../user/canfd.h:

../user/ringbuffer.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlib.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlibf.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h:

../user/iap.h:

../user/flash_eeprom.h:

../user/Flash_ADP32F03x_API_Library.h:

../user/Flash_ADP32F03x_API_Config.h:

../user/mm.h:

