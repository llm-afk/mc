# FIXED

user/kalman_velocity_q15.obj: ../user/kalman_velocity_q15.c
user/kalman_velocity_q15.obj: ../user/kalman_velocity_q15.h

../user/kalman_velocity_q15.c:

../user/kalman_velocity_q15.h:

