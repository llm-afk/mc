# FIXED

Function/ParameterHuaHui.obj: ../Function/ParameterHuaHui.c
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Define.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Main.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Function/ParameterHuaHui.obj: C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Interface.h

../Function/ParameterHuaHui.c:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Define.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Main.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Interface.h:

