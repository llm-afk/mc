################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Function/CommInterface.c \
../Function/Command.c \
../Function/FunctionMain.c \
../Function/LinLDF.c \
../Function/Parameter_FT_FAN.c \
../Function/PreDrive.c \
../Function/Reference.c \
../Function/SPIcomm.c 

C_DEPS += \
./Function/CommInterface.d \
./Function/Command.d \
./Function/FunctionMain.d \
./Function/LinLDF.d \
./Function/Parameter_FT_FAN.d \
./Function/PreDrive.d \
./Function/Reference.d \
./Function/SPIcomm.d 

OBJS += \
./Function/CommInterface.obj \
./Function/Command.obj \
./Function/FunctionMain.obj \
./Function/LinLDF.obj \
./Function/Parameter_FT_FAN.obj \
./Function/PreDrive.obj \
./Function/Reference.obj \
./Function/SPIcomm.obj 

OBJS__QUOTED += \
"Function\CommInterface.obj" \
"Function\Command.obj" \
"Function\FunctionMain.obj" \
"Function\LinLDF.obj" \
"Function\Parameter_FT_FAN.obj" \
"Function\PreDrive.obj" \
"Function\Reference.obj" \
"Function\SPIcomm.obj" 

C_DEPS__QUOTED += \
"Function\CommInterface.d" \
"Function\Command.d" \
"Function\FunctionMain.d" \
"Function\LinLDF.d" \
"Function\Parameter_FT_FAN.d" \
"Function\PreDrive.d" \
"Function\Reference.d" \
"Function\SPIcomm.d" 

C_SRCS__QUOTED += \
"../Function/CommInterface.c" \
"../Function/Command.c" \
"../Function/FunctionMain.c" \
"../Function/LinLDF.c" \
"../Function/Parameter_FT_FAN.c" \
"../Function/PreDrive.c" \
"../Function/Reference.c" \
"../Function/SPIcomm.c" 


