# FIXED

Function/FunctionMain.obj: ../Function/FunctionMain.c
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Main.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Interface.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/RunSrc.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Reference.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/FuncUser.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
Function/FunctionMain.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/LinLDF.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/PreDriver.h
Function/FunctionMain.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/AngleSensor.h

../Function/FunctionMain.c:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Main.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Interface.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/RunSrc.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Reference.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/FuncUser.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/LinLDF.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/PreDriver.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/AngleSensor.h:

