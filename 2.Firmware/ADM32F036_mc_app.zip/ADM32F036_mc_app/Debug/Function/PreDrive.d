# FIXED

Function/PreDrive.obj: ../Function/PreDrive.c
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/PreDriver.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Main.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Interface.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
Function/PreDrive.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h
Function/PreDrive.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c_defines.h

../Function/PreDrive.c:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/PreDriver.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Main.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Interface.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c_defines.h:

