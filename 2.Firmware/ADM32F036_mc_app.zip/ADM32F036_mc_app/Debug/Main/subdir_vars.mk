################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
ASM_SRCS += \
../Main/ADP32F03x_CSMPasswords.asm \
../Main/ADP32F03x_CodeStartBranch.asm \
../Main/ADP32F03x_usDelay.asm 

C_SRCS += \
../Main/ADP32F03x_CpuTimers.c \
../Main/ADP32F03x_GlobalVariableDefs.c \
../Main/HardwareSetup.c \
../Main/MainSystem.c 

C_DEPS += \
./Main/ADP32F03x_CpuTimers.d \
./Main/ADP32F03x_GlobalVariableDefs.d \
./Main/HardwareSetup.d \
./Main/MainSystem.d 

OBJS += \
./Main/ADP32F03x_CSMPasswords.obj \
./Main/ADP32F03x_CodeStartBranch.obj \
./Main/ADP32F03x_CpuTimers.obj \
./Main/ADP32F03x_GlobalVariableDefs.obj \
./Main/ADP32F03x_usDelay.obj \
./Main/HardwareSetup.obj \
./Main/MainSystem.obj 

ASM_DEPS += \
./Main/ADP32F03x_CSMPasswords.d \
./Main/ADP32F03x_CodeStartBranch.d \
./Main/ADP32F03x_usDelay.d 

OBJS__QUOTED += \
"Main\ADP32F03x_CSMPasswords.obj" \
"Main\ADP32F03x_CodeStartBranch.obj" \
"Main\ADP32F03x_CpuTimers.obj" \
"Main\ADP32F03x_GlobalVariableDefs.obj" \
"Main\ADP32F03x_usDelay.obj" \
"Main\HardwareSetup.obj" \
"Main\MainSystem.obj" 

C_DEPS__QUOTED += \
"Main\ADP32F03x_CpuTimers.d" \
"Main\ADP32F03x_GlobalVariableDefs.d" \
"Main\HardwareSetup.d" \
"Main\MainSystem.d" 

ASM_DEPS__QUOTED += \
"Main\ADP32F03x_CSMPasswords.d" \
"Main\ADP32F03x_CodeStartBranch.d" \
"Main\ADP32F03x_usDelay.d" 

ASM_SRCS__QUOTED += \
"../Main/ADP32F03x_CSMPasswords.asm" \
"../Main/ADP32F03x_CodeStartBranch.asm" \
"../Main/ADP32F03x_usDelay.asm" 

C_SRCS__QUOTED += \
"../Main/ADP32F03x_CpuTimers.c" \
"../Main/ADP32F03x_GlobalVariableDefs.c" \
"../Main/HardwareSetup.c" \
"../Main/MainSystem.c" 


