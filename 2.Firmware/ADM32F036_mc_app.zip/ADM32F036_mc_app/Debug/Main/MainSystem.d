# FIXED

Main/MainSystem.obj: ../Main/MainSystem.c
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SPIcomm.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/AngleSensor.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/stimer.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stddef.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/flash_eeprom.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/Flash_ADP32F03x_API_Library.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/Flash_ADP32F03x_API_Config.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/mm.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/canfd.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/ringbuffer.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlib.h
Main/MainSystem.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlibf.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/iap.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/od.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/motor_ctrl.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/encoder.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/motor_ctrl.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/utils.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/od.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/led.h
Main/MainSystem.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/lpg.h

../Main/MainSystem.c:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SPIcomm.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/AngleSensor.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/stimer.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stddef.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/string.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/xlocale/_string.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/flash_eeprom.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/Flash_ADP32F03x_API_Library.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/Flash_ADP32F03x_API_Config.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/mm.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/canfd.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/ringbuffer.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlib.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdlibf.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/iap.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/od.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/motor_ctrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/encoder.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/motor_ctrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/utils.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/od.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/led.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/lpg.h:

