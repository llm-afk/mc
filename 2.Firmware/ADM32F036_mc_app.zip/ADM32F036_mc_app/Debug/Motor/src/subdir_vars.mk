################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Motor/src/InfoCollect.c \
../Motor/src/InvProtect.c \
../Motor/src/MCCall.c \
../Motor/src/MCExchange.c \
../Motor/src/MCMain.c \
../Motor/src/MCVF.c \
../Motor/src/MCVar.c \
../Motor/src/Tune.c 

C_DEPS += \
./Motor/src/InfoCollect.d \
./Motor/src/InvProtect.d \
./Motor/src/MCCall.d \
./Motor/src/MCExchange.d \
./Motor/src/MCMain.d \
./Motor/src/MCVF.d \
./Motor/src/MCVar.d \
./Motor/src/Tune.d 

OBJS += \
./Motor/src/InfoCollect.obj \
./Motor/src/InvProtect.obj \
./Motor/src/MCCall.obj \
./Motor/src/MCExchange.obj \
./Motor/src/MCMain.obj \
./Motor/src/MCVF.obj \
./Motor/src/MCVar.obj \
./Motor/src/Tune.obj 

OBJS__QUOTED += \
"Motor\src\InfoCollect.obj" \
"Motor\src\InvProtect.obj" \
"Motor\src\MCCall.obj" \
"Motor\src\MCExchange.obj" \
"Motor\src\MCMain.obj" \
"Motor\src\MCVF.obj" \
"Motor\src\MCVar.obj" \
"Motor\src\Tune.obj" 

C_DEPS__QUOTED += \
"Motor\src\InfoCollect.d" \
"Motor\src\InvProtect.d" \
"Motor\src\MCCall.d" \
"Motor\src\MCExchange.d" \
"Motor\src\MCMain.d" \
"Motor\src\MCVF.d" \
"Motor\src\MCVar.d" \
"Motor\src\Tune.d" 

C_SRCS__QUOTED += \
"../Motor/src/InfoCollect.c" \
"../Motor/src/InvProtect.c" \
"../Motor/src/MCCall.c" \
"../Motor/src/MCExchange.c" \
"../Motor/src/MCMain.c" \
"../Motor/src/MCVF.c" \
"../Motor/src/MCVar.c" \
"../Motor/src/Tune.c" 


