# FIXED

Motor/src/MCVF.obj: ../Motor/src/MCVF.c
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h
Motor/src/MCVF.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h
Motor/src/MCVF.obj: C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h

../Motor/src/MCVF.c:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Define.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Canfd.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader/ADP32F03x_Analog.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_ti_config.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/linkage.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/_stdint40.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/cdefs.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_types.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/machine/_stdint.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include/sys/_stdint.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/Parameter.h:

C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader/SubPrgInclude.h:

