# FIXED

Motor/src/IPD.obj: ../Motor/src/IPD.c
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MainInclude.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Define.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/SubPrgInclude.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Parameter.h
Motor/src/IPD.obj: C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Record.h

../Motor/src/IPD.c:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Define.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/SubPrgInclude.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Parameter.h:

C:/Users/Advancechip/Desktop/jiqirenguanjiedianji/ADM32F036C1_DEMO20251121_OBJ/HeardFiles/SourceHeader/Record.h:

