################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
ASM_SRCS += \
../SubProgra/ASMSubPrg.asm 

C_SRCS += \
../SubProgra/Record.c \
../SubProgra/SubPrg.c 

C_DEPS += \
./SubProgra/Record.d \
./SubProgra/SubPrg.d 

OBJS += \
./SubProgra/ASMSubPrg.obj \
./SubProgra/Record.obj \
./SubProgra/SubPrg.obj 

ASM_DEPS += \
./SubProgra/ASMSubPrg.d 

OBJS__QUOTED += \
"SubProgra\ASMSubPrg.obj" \
"SubProgra\Record.obj" \
"SubProgra\SubPrg.obj" 

C_DEPS__QUOTED += \
"SubProgra\Record.d" \
"SubProgra\SubPrg.d" 

ASM_DEPS__QUOTED += \
"SubProgra\ASMSubPrg.d" 

ASM_SRCS__QUOTED += \
"../SubProgra/ASMSubPrg.asm" 

C_SRCS__QUOTED += \
"../SubProgra/Record.c" \
"../SubProgra/SubPrg.c" 


