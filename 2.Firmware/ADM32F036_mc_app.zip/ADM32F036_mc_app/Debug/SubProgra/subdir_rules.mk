################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
SubProgra/%.obj: ../SubProgra/%.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla0 -O4 --opt_for_speed=5 --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app" --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader" --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader" --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user" --include_path="D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --advice:performance=all --define=SHORT_GND_TEST_N --define=IPD_PERIOD_AUTO_DECT_n --define=INTER_OSC_N --define=KE_WIDE_RANGE --define=IPD_PERIOD_AUTO_DECT_N --define=FREQUENCY_CONTROL_01HZ_N --define=CUT_DOWN_VER_HARDWARE --define=OPEN_LOOP_START_N --define=FULL_OPEN_LOOP_MODE_N --define=LIN_CONTROL_MODE --define=INTER_OSC11 --define=LARGE_MODEL --define=SPIN_CONTROL_WITH_BEMF -g --c99 --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="SubProgra/$(basename $(<F)).d_raw" --obj_directory="SubProgra" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

SubProgra/%.obj: ../SubProgra/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla0 -O4 --opt_for_speed=5 --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app" --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/SourceHeader" --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/HeardFiles/ADP32F03xHeader" --include_path="C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user" --include_path="D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --advice:performance=all --define=SHORT_GND_TEST_N --define=IPD_PERIOD_AUTO_DECT_n --define=INTER_OSC_N --define=KE_WIDE_RANGE --define=IPD_PERIOD_AUTO_DECT_N --define=FREQUENCY_CONTROL_01HZ_N --define=CUT_DOWN_VER_HARDWARE --define=OPEN_LOOP_START_N --define=FULL_OPEN_LOOP_MODE_N --define=LIN_CONTROL_MODE --define=INTER_OSC11 --define=LARGE_MODEL --define=SPIN_CONTROL_WITH_BEMF -g --c99 --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="SubProgra/$(basename $(<F)).d_raw" --obj_directory="SubProgra" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


