################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -llibc.a -l"C:/Users/32196/Desktop/mc/2.Firmware/ADM32F036_mc_app/user/ADP32F036_027_Flash_API_ZONE.lib"

