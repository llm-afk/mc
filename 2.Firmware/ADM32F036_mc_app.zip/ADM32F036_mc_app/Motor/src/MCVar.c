

#include "MotorInclude.h"


int  gSendToFunctionDataBuff[MOTOR_TO_FUNCTION_DATA_NUM];
Uint gSendToMotorDataBuff[FUNCTION_TO_MOTOR_DATA_NUM];				//���ݸ�����ģ�������

INV_STRUCT 				gInvInfo;		//��Ƶ����Ϣ
MOTOR_STRUCT 			gMotorInfo;		//�����Ϣ

RUN_STATUS_STRUCT 		gMainStatus;	//������״̬
BASE_COMMAND_STRUCT		gMainCmd;		//������

/************************************************************/
/**********����Ϊ�͵����������趨��������******************/
BASE_PAR_STRUCT			gBasePar;		//�������в���
COM_PAR_INFO_STRUCT		gComPar;		//��������
VF_INFO_STRUCT			gVFPar;			//VF����

ADC_STRUCT				gADC;			//ADC���ݲɼ��ṹ
UDC_STRUCT				gUDC;			//ĸ�ߵ�ѹ����
IUVW_SAMPLING_STRUCT	gCurSamp;
UVW_STRUCT				gIUVW;			//�����������������
ALPHABETA_STRUCT		gIAlphBeta;		//�����������������
MT_STRUCT				gIMT;			//MT��ϵ�µĵ���
AMPTHETA_STRUCT			gIAmpTheta;		//�������ʾ�ĵ���
LINE_CURRENT_STRUCT		gLineCur;	
ANGLE_STRUCT			gPhase;			//�ǶȽṹ
JUDGE_POWER_LOW			gLowPower;		//�ϵ绺���ж�ʹ�����ݽṹ
JUDGE_ACC_DEC_STRUCT	gSpeedFlag;		//�жϼӼ��ٱ�־�Ľṹ
CUR_EXCURSION_STRUCT	gExcursionInfo;	//�����Ưʹ�õĽṹ
DEAD_BAND_STRUCT		gDeadBand;

CBC_PROTECT_STRUCT      gCBCProtect;
TEMPLETURE_STRUCT		gTemperature;
PHASE_LOSE_STRUCT		gPhaseLose;
	
FC_CAL_STRUCT			gFcCal;
OVER_UDC_CTL_STRUCT		gOvUdc;
DC_BRAKE_STRUCT         gDCBrake;
OUT_VOLT_STRUCT			gOutVolt;
Uint					gRatio;			//����ϵ��
PWM_OUT_STRUCT			gPWM;

SYN_PWM_STRUCT			gSynPWM;
UV_AMP_COFF_STRUCT		gUVCoff;
FEISU_STRUCT			gFeisu;			//ת�ٸ����ñ���
CPU_TIME_STRUCT			gDSPActiveTime;

PM_INIT_POSITION        gIPMInitPos;
PM_FLUX_WEAK		    gFluxWeak;
SHORT_GND_STRUCT        gShortGnd;
BEMF_STRUCT             gBemf;
PG_STRUCT               gPG;
//---------------------------------------------------------------
//�������ģ��Ϳ���ģ��Ľ�����
//---------------------------------------------------------------
Uint MotorPWMRandom;
Uint MotorSpeedScaling2ONKB10;

Uint DCBrakeCur;
Uint TorqueCurrentLimit;
Uint OverspeedScaling;
Uint SpeedFeedbackFilter;
Uint SFLowSpeed;
Uint MinCurrentLowSpeed;
Uint SpecailFactor;
Uint SpeedMeasureFactor1;
Uint SpeedMeasureFactor2;
Uint StartPresetCurrent;
Uint LowLimitFrequency;
Uint FieldWeakMode;
Uint FieldWeakCurScale;
Uint FieldWeakScale;
Uint FieldWeakRef;
Uint DataRsrd;
Uint IPDAutoDectEnable;
Uint IPDAutoDectScaling;

Uint IdMaxSet;
Uint IqFWLimit;

Uint AVREnableMode;
Uint MotorTestData1;
Uint MotorTestData2;
Uint NoNegativeOMG;
Uint MotorTestData4;
Uint MotorTestData5;
Uint MotorPWMModeForNoise;
Uint ReserdData;
Uint DCBrakeCur;
Uint RsSecond;
Uint PaseShiftEnable = 1;
Uint LowNoseElmPWMMode;
Uint LastLowNoseElmPWMMode;
int  InternalTemperatureDegree;
int IbusActual;
int ActualPower;

Uint * const gSendToMotorTable[FUNCTION_TO_MOTOR_DATA_NUM] = 
{
	(Uint *)&gMainCmd.Command.all,	(Uint *)&gMainCmd.FreqSet,			//0��1
	(Uint *)&gMainCmd.VCTorqueLim,	&DataRsrd,		                    //2��3
	&gBasePar.FcSet,				&gBasePar.UpFreq,					//4��5
	&gVFPar.VFLineType,													//6
	&gBasePar.MaxFreq,				&gMotorInfo.Power,					//7��8
	&MotorPWMModeForNoise,											    //9
	&gMotorInfo.Power,                      							//10
	&gMotorInfo.Votage,				&gMotorInfo.CurrentGet,				//11��12
	&gMotorInfo.Frequency,												//13
	&IdMaxSet,                      &DataRsrd,        	                //14��15
	&gInvInfo.InvUpUDCCoef,			&gInvInfo.InvLowUDCCoef,			//16��17
	&gComPar.SubCommand.all,		&ReserdData,                        //18��19
	&gInvInfo.UDCCoff,				&gInvInfo.CurrentCoff,              //20��21
	&MotorPWMRandom, 	    		&IqFWLimit,			                //22��23
	&gADC.DelaySet,                         							//24
	&DCBrakeCur,                     				//25

    &TorqueCurrentLimit,
    &OverspeedScaling,
    &SpeedFeedbackFilter,
    &SFLowSpeed,
    &MinCurrentLowSpeed,
    &SpecailFactor,
    &SpeedMeasureFactor1,
    &SpeedMeasureFactor2,
    &StartPresetCurrent,
    &LowLimitFrequency,
    &FieldWeakMode,
    &FieldWeakCurScale,
    &FieldWeakScale,
    &FieldWeakRef,
    &IPDAutoDectEnable,
    &IPDAutoDectScaling,

    &AVREnableMode,
    &MotorTestData1,
    (Uint *)&cof_uwMaxThetaPerCntTcPu,
    &NoNegativeOMG,
    &MotorTestData4,
    &MotorTestData5,
}; 
 
Uint gSoftVersion = SOFT_VERSION;
Uint * const gSendToFuncTable[MOTOR_TO_FUNCTION_DATA_NUM] = 
{
	&gMainStatus.StatusWord.all,	&gMainStatus.ErrorCode,				//0��1
	(Uint *)&gLineCur.ErrorShow,	(Uint *)&gMainCmd.FreqPreWs,				//2��3
	(Uint *)&gUDC.uDCFilter,		(Uint *)&gLineCur.CurPer,			//4��5
	(Uint *)&gOutVolt.VoltApply,	&gTemperature.Temp,					//6��7
	(Uint *)&gMainStatus.RunStep,	(Uint *)&pm_iq_show,				//8��9
	(Uint *)&pm_omg_show,			&gInvInfo.InvCurrent
};
