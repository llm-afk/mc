

#include "MotorInclude.h"
#include "Main.h"
#include "Record.h"
#include "Parameter.h"
#include "FuncUser.h"
#include "RunSrc.h"
#include "Reference.h"
#include "PreDriver.h"
#include "AngleSensor.h"
#include "encoder.h"

void ParameterChange(void);	
void CalCarrierWaveFreq(void);
void RunCaseDeal(void);
void RunCaseLowPower(void);
void RunCaseGetPar(void);
void RunCaseSpeedCheck(void);
void PrepareForSpeedCheck(void);
void RunCaseRun(void);
void OpenLoopAccRun(void);
void RunCaseBrakeLowBridge(void);
void RunCaseStop(void);
void RunCaseShortGnd(void);
void PrepareParForRun(void);
void CalStepAngle(void);

void CalRatioFromVot(void);
void CalDeadBandComp(void);
void SoftPWMProcess(void);
void CalOutputPhase(void);
void GetCurrentExcursion(void);

void SoftWareErrorDeal(void);					
void CalUdcLimitIT(void);
void SoftDebug(void);
// SpeedFromTransFiltered removed - speed loop not needed

//int IsRelayCheckFinshed;
UDC_LIMIT_IT_STRUCT gUdcLimitIt;
long pm_fast_freq;
long LimitHGlobal = 4096;
int DCStart_flag = 0;
int IDFadeOverCnt;
int SHORT_GND_PERIOD = 5000;    // 10K SF

/************************************************************
����ģ���ʼ��������ѭ��ǰ��ʼ�����ܲ��ֵı���(���е���0�ı��������ʼ��)
************************************************************/
void  InitForMotorApp(void)
{
    DisableDrive();

	gMainStatus.RunStep = STATUS_LOW_POWER;
	gMainStatus.SubStep = 1;

	gMainStatus.LastErrorCode = gMainStatus.ErrorCode;

	gMainStatus.StatusWord.all = 0;
	gADC.DelaySet = 100;

	gFcCal.FcBak = 200;
	gBasePar.FcSetApply = 200;

    gPWM.gPWMPrd = 500000 / gBasePar.FcSetApply;
    gPWM.gPWMPrdApply = 500000 / gBasePar.FcSetApply;

	pm_control_mode = PMSM_CONTROL_MODE_FOC;
    DCStart_flag = 0;
}

/************************************************************
������ĵ�2msѭ��������ִ�е�����Ƴ���
˼·����������->����ת��->�����㷨->�������->���ұ���
ִ��ʱ�䣺�����жϴ�ϵ������Լ120us
************************************************************/
void SystemLeve2msMotor(void)
{
	ParGetFromFunction();
	ParameterChange();
	PMFluxWeaking();

	// CalCarrierWaveFreq(); // ��̬�޸��ز�Ƶ��
	CalStepAngle();
	RunCaseDeal();
							
	InvDeviceKontrol();
	SoftWareErrorDeal();
	GetCurrentExcursion();
	ParSendToFunction();

	// from 125us interrupt function
	// GetAIInfo();			// 0.36%
	// GetTemperatureInfo();	// 0.74%
	ADCProcess();			// 1.05%
	calc_pm_coef();			// 22.1%
	GetUDCInfo();			// 0.9%
	GetIDCInfo();
	ChangeCurrent_2ms();
	PMSMSVC_2ms();
	PMCalcLineCurr();
}

/************************************************************
������0.5msѭ��������ִ����Ҫ����ˢ�µĳ���Ҫ�����ǳ����
************************************************************/
void SystemLeve05msMotor(void)
{
    if (pm_control_mode != 0)
    {
        return;
    }
    RunCaseDeal();
}



/*************************************************************
�������������ɲ���ת�������в���׼���ȹ���
*************************************************************/
void ParameterChange(void)		
{
	Ulong	m_ULong;
	Uint 	m_UData;

	// gInvInfo.InvVoltageType
	gInvInfo.InvVolt = MOTOR_RATED_VOL;

	// ȷ����ѹ��Ƿѹ��Ĵ�С...
	// LowDc = 200V
	// InvUpUDC = OverDc = 390V
	gInvInfo.InvLowUDC = gInvInfo.InvLowUDCCoef;
	gInvInfo.InvUpUDC  = gInvInfo.InvUpUDCCoef;

#if 0
	// 12V Drive, ONLY 7 8 9 Can be used.
	// * 14480) >> 10 = 113
	// * 960) >> 6    = 120
	gInvInfo.BaseUdc = ((long)MOTOR_RATED_VOL * 14480) >> 10;
#else
    gInvInfo.BaseUdc = ((long)MOTOR_RATED_VOL * 960) >> 6;
#endif

	// ��ѹʧ�ٵ� 351V = gOvUdc.Limit...
	gOvUdc.Limit = OVER_DC_VOL_LIMIT;

	// �趨�������ʵ�ʲ�Ʒ���Կ��ǽ�������Ϊ�̶�ֵ���ȵ�������һ��
	gInvInfo.InvCurrent = MOTOR_RATED_CUR;

	// gUDC.Coff = 9500, ����3.3V ~ 950V and with 0.1 DP
	// ����2802x ��ֱ�ӽ�gUDC.Coff �ĳ�һ���̶�ֵ���ɡ�
    // 443.3V, then 4433/
	gUDC.Coff = MAX_DC_VOL_3_3V;

	//���õ������̫С�Ĵ���
	gMotorInfo.Current = gMotorInfo.CurrentGet;

	// ����������������������, ʵ�ʲ�Ʒ����Ϊ�̶� 2us
    gDeadBand.DeadBand = DeadTimeInternal;
    gDeadBand.Comp     = DeadTimeCompInternal;

	EALLOW;									//��������ʱ��
	EPwm2Regs.DBFED = gDeadBand.DeadBand;
	EPwm2Regs.DBRED = gDeadBand.DeadBand;
	EPwm3Regs.DBFED = gDeadBand.DeadBand;
	EPwm3Regs.DBRED = gDeadBand.DeadBand;
	EPwm4Regs.DBFED = gDeadBand.DeadBand;
	EPwm4Regs.DBRED = gDeadBand.DeadBand;
	EDIS;
	
	// 24.75A
    // MAX_PEAK_CUR_3_3V = 414, �������� 4.14A Peak. Rated is 2.0A
    // (4.14 / 2.0) * 2^12 = 8448,
    m_ULong = MAX_PEAK_CUR_3_3V_410;
    m_ULong = m_ULong / gMotorInfo.Current;
    gCurSamp.Coff = m_ULong;

	//����Ƶ�ʱ�ʾ
#ifdef  FREQUENCY_CONTROL_01HZ
    gBasePar.FullFreq = ((long)gBasePar.MaxFreq * 10) + 2000;
#else
    gBasePar.FullFreq = gBasePar.MaxFreq + 2000;
#endif

	gMotorInfo.FreqPer = ((Ulong)gMotorInfo.Frequency <<15) / gBasePar.FullFreq;

	//������ʵ��ֵ��ʾ������Ƶ��
	m_UData = abs(gMainCmd.FreqSetApply);
	gMainCmd.FreqReal = ((Ulong)m_UData * (Ulong)gBasePar.FullFreq) >> 15;
}

/************************************************************
 �����ز�Ƶ�ʣ�����gBasePar.FcSet�����gBasePar.FcSetApply
 2ms Level...
************************************************************/
void CalCarrierWaveFreq(void)
{
	Uint	m_TempLim,m_MaxFc,m_MinFc;
	long    data,data1,freqs,freqs1,fcSet;

    fcSet = gBasePar.FcSet;   //l0310

#ifdef DSP_CLOCK100
   	data = (500000L * 512);
#elif   DSP_CLOCK60
    data = (300000L * 512);
#else
    data = (200000L * 512);
#endif  

	if (gMainStatus.RunStep != STATUS_RUN) {
		data = __IQsat(gBasePar.FcSet,200,20);
		gBasePar.FcSetApply = data;
		return;
	}

	if (pm_control_mode != 0) {
	   if ((gMainStatus.RunStep       == STATUS_SPEED_CHECK) ||
	   	(gMainCmd.Command.bit.StartDC == 1                 ))
	   {
			data = 180;//100;
			gBasePar.FcSetApply = data;
			return;
	   }
	  
	   data1 = pm_bem_kf;
	   if (data1 < 50) {
	       data1 = 50;
	   } 

	   // 102, then 4000000 / 102 = 39215
	   // means 24.38Hz,ˮ�õ�����5���ң����� 4000000 / 5 = 800000�� ����50HZ. ƫ��
	   // �ĳ�200000 / ke�� ����KE=5ʱ��50HZ ��ʼ���ż�С��0
	   ///////////////////////////////////////////////////////////////////////////
	   if (MotorTestData5 == 1) {
	       freqs = 4000000L/data1;
	   } else {
	       freqs = 400000L/data1;
	   }

	   if (pm_control_mode == 1) {
		   data = pm_ref_speed;
	   } else {
		   data = pm_est_lpf_omg;
	   }
	   freqs1 = labs(data);	   

#define SF_INDEPAND_OF_FREQUENCY	1
#ifdef  SF_INDEPAND_OF_FREQUENCY
	   fcSet = gBasePar.FcSet;
#else
	   // ������Ƶ��Ĭ��FE��10 = 3.0KHz
	   if(freqs1 < 32767L)
	   {
		   fcSet = SF_LOW_SPEED;
	   } else if(freqs1 >= 65536L) {
	   	   fcSet = gBasePar.FcSet;
	   } else {
		   data = freqs1 - 32767L;
		   data = data * ((long)gBasePar.FcSet - (long)SF_LOW_SPEED)>>15;
	       fcSet = data + SF_LOW_SPEED;
	   }
	   if (SF_LOW_SPEED >= gBasePar.FcSet) {
			fcSet = gBasePar.FcSet;
	   }
#endif
	   
	   // ����Id �ĸ�����С....
	   // 24.38Hz �������Ա仯...
	   //////////////////////////
	   if(freqs1 > 2*freqs) {
			data1 = 0;
	   } else if(freqs1 == 0) {
	  		pm_min_curr = 0;
	   } else {
	   		data = MIN_CUR_LOW_SPEED * 80;
            if (MotorTestData5 == 1) {
                if (pm_bem_kf >= 4000) {
                    data = data * 3000L/pm_bem_kf;
                }
            } else {
                if (pm_bem_kf >= 400) {
                    data = data * 300L/pm_bem_kf;
                }
            }
			data1 = data * freqs1/freqs;
	   		data1 = data - (data1>>1);
	   		data1 = __IQsat(data1,data,0);
	   }
	   // �����趨ת�ص���ֵ����������...
	   data = (long)TORQUE_CUR_LIMIT * 4096L/100;
	   data = data * data - (long)pm_ref_iq * pm_ref_iq;
	   if (data < 0) {
		   data = 0;
	   }
	   data = qsqrt(data);
	   if(data1 > data) {
		   data1 = data;
	   }
	   pm_min_curr = data1;
	}

	gFcCal.Time++;
	gFcCal.Cnt += gBasePar.FcSetApply;
	if (gFcCal.Cnt < 100) {
		return;
	}
	gFcCal.Cnt = 0;

	// �˴���FC���¶ȹ�ϵ�ļ���
	m_TempLim = 185;
	if (gTemperature.Temp > (m_TempLim - 5))		//�¶ȴ��ڣ�����ֵ-5����
	{
		if(gFcCal.Time >= 2500)						//ÿ5�����һ��  l0310
		{
			gFcCal.Time = 0;
			if(gTemperature.Temp <= m_TempLim)		//�ز�Ƶ����
			{
				gFcCal.FcBak += 5;
			} else if(gTemperature.Temp >= (m_TempLim+5)) {
				gFcCal.FcBak -= 5;
				gFcCal.FcBak = (gFcCal.FcBak<20)?20:gFcCal.FcBak;
			}
		}
	} else {
		gFcCal.Time = 0;
		gFcCal.FcBak = fcSet; 
	}
    gFcCal.FcBak = (gFcCal.FcBak>fcSet)?fcSet:gFcCal.FcBak;

	// ��ʼ��FC��������С����
	m_MinFc = 100;
	m_MaxFc = 200;
	gFcCal.FcBak = __IQsat(gFcCal.FcBak,m_MaxFc,m_MinFc);

	// ��ʼ�����ز�Ƶ�ʣ�ÿ40ms����0.1KHz��
	if (gFcCal.FcBak > gBasePar.FcSetApply) {
		gBasePar.FcSetApply++;
	} else if(gFcCal.FcBak < gBasePar.FcSetApply) {
		gBasePar.FcSetApply--;
	}

#if 0
    if (gMainCmd.FreqReal > 25000 + 300)
    {
        gPWM.PWMModle = MODLE_DPWM;
    }
    else if( gMainCmd.FreqReal < 25000)
    {
        gPWM.PWMModle = MODLE_CPWM;
    }
#else
    gPWM.PWMModle = MODLE_CPWM;
#endif
}

void RunCaseDeal(void)
{
	switch(gMainStatus.RunStep)
	{
		case STATUS_LOW_POWER:	//�ϵ绺��״̬/Ƿѹ״̬
			RunCaseLowPower();
			break;

		case STATUS_GET_PAR:	//������ʶ״̬
			RunCaseGetPar();
			break;

		case STATUS_SPEED_CHECK://ת�ٸ���״̬
			RunCaseSpeedCheck();
			break;

		case STATUS_RUN:		//����״̬������VF/FVC/SVC����
			RunCaseRun();
			CalUdcLimitIT();
			break;

        case OPEN_ACC:
        case HALF_OPEN_ACC:
		    OpenLoopAccRun();
		    break;

        case STATUS_BRAKE:
            RunCaseBrakeLowBridge();
            break;

        case STATUS_SHORT_GND:	//�ϵ�Եض�·�ж�״̬
			RunCaseShortGnd();
			break;

		default:				//ͣ��״̬����������״̬��Ϊ�Ǹ�״̬
			RunCaseStop();
			break;
	}	
}

void RunCaseLowPower(void)
{
	Uint uDCLowLimt;
	uDCLowLimt = gInvInfo.InvLowUDC + 10;
	switch (gMainStatus.SubStep)
	{
		case 2:
			if((gUDC.uDCFilter > uDCLowLimt) && (gUDC.uDCFilter <= gLowPower.UDCOld))
			{
				if ((gLowPower.WaiteTime++) >= 100) {
					gExcursionInfo.EnableCount = 199;
					gMainStatus.SubStep ++;	
					gLowPower.WaiteTime = 0;			
				}
			} else {
				gLowPower.WaiteTime = 0;
				gLowPower.UDCOld = gUDC.uDCFilter;
			}

			break;

		case 3:
			// 200ms��ʱ
			if (((gLowPower.WaiteTime++) >= 100) && (gExcursionInfo.EnableCount >= 200))
			{
				gMainStatus.RunStep = STATUS_STOP;
				gMainStatus.SubStep = 1;
                gMainStatus.StatusWord.bit.LowUDC = 0;
				gMainStatus.StatusWord.bit.RunEnable = 1;
        		if(gMainStatus.ErrorCode == ERROR_UV)
                {
                    gMainStatus.ErrorCode = 0;
		            if(gMainStatus.ErrFlag.bit.OvCurFlag == 1)  //�޸�Ƿѹ���޷���������жϵĴ���
		            {
			            gMainStatus.ErrFlag.bit.OvCurFlag = 0;
			            EALLOW;
			            EPwm2Regs.TZCLR.bit.OST = 1;
			            EPwm3Regs.TZCLR.bit.OST = 1;
			            EPwm4Regs.TZCLR.bit.OST = 1;

                        EPwm2Regs.TZCLR.bit.CBC = 1;
                        EPwm3Regs.TZCLR.bit.CBC = 1;
                        EPwm4Regs.TZCLR.bit.CBC = 1;

                        // EPWM.PDF TI, Page 64
                        // The TZFLG[DCAEVT1/2] or TZFLG[DCBEVT1/2] flag bit will remain set until it is manually
                        // cleared by writing to the TZCLR[DCAEVT1/2] or TZCLR[DCBEVT1/2] bit. If the DC trip event is still
                        // present when the TZFLG[DCAEVT1/2] or TZFLG[DCBEVT1/2] flag is cleared, then it will again be
                        // immediately set
                        EPwm2Regs.TZCLR.bit.DCAEVT1 = 1;
                        EPwm3Regs.TZCLR.bit.DCAEVT1 = 1;
                        EPwm4Regs.TZCLR.bit.DCAEVT1 = 1;

                        EPwm2Regs.TZCLR.bit.DCBEVT2 = 1;
                        EPwm3Regs.TZCLR.bit.DCBEVT2 = 1;
                        EPwm4Regs.TZCLR.bit.DCBEVT2 = 1;

                        EPwm2Regs.TZCLR.bit.INT = 1;
			            EDIS;
		            }     
        		}

				gPhase.IMPhase = GetTime() << 28;	//�ϵ�����ѡ���ʼ��λ
			}
			break;

		default:
			DisConnectRelay();	
            gMainStatus.ErrorCode = ERROR_UV;				//����־
        	gMainStatus.StatusWord.bit.LowUDC = 1;
			gLowPower.WaiteTime = 0;
			gLowPower.UDCOld = gUDC.uDCFilter;
			gMainStatus.SubStep = 2;
			break;
	}
}

/************************************************************
	������ʶ�׶�(�ó������ڼ��U���V��������ͨ��������ƫ��)
	ͬʱ��ⶨ�ӵ���ֵ��
	2ms ״̬��...
************************************************************/
void RunCaseGetPar(void)
{
}


/************************************************************
	ת�ٸ���״̬����
	2ms, ״̬��...
	��������÷��綯���������
	ˮ�û�������ֱ�ӵ����ջ�..
************************************************************/
void RunCaseSpeedCheck(void)
{
	long data;
	if ((gMainCmd.Command.bit.Start == FALSE) ||        //ͣ������
	    (gMainStatus.ErrorCode      != 0    ))			//����
	{ 
		gMainStatus.RunStep = 3;
		gMainStatus.SubStep = 1;
		DisableDrive();
		return;
	}

#ifdef SPIN_CONTROL_WITH_BEMF
	PaseShiftEnable = 1;
#else
#if (SINGLE_SHUNT_PWM_MODE == NORMAL_NOISE_PWM_MODE)
	PaseShiftEnable = 0;
#else
    PaseShiftEnable = 1;
#endif
#endif

//SpeedData[0]++;
	// ״̬����200ms, Ȼ����뵽RUN ״̬, gMainCmd.FreqSetApply �������ӹ���
	// ���ݹ�����������
	////////////////////////////////////////////////////////////////////////
	if (pm_control_mode != 0)
	{
		gFeisu.VoltCNT++;
#ifdef SPIN_CONTROL_WITH_BEMF
		if (ReadSpeedBasedonFinished == 1)
#else
		if (gFeisu.VoltCNT > 100)
#endif
		{
			gFeisu.VoltCNT = 0;
//SpeedData[2]=pm_est_lpf_omg1 >> 4;
//SpeedData[3]++;
#ifdef SPIN_CONTROL_WITH_BEMF
            pm_est_lpf_omg1 = (long)gBemf.Spd_Hz * 1602L;
#endif
			data = (long long)pm_est_lpf_omg1 * 2045L / gBasePar.FullFreq;
            if ((pm_est_lpf_omg1 <= 8010) && (pm_est_lpf_omg1 >= (-8010)))
			{
//SpeedData[4]++;
#ifdef IPD_PERIOD_AUTO_DECT
                pm_check_ip_flag = 1;
                data = 0;
#else
                pm_check_ip_flag = 0;
                DCStart_flag = 1;
#endif
				gIPMInitPos.SubStep = 1;
			}
            gMainCmd.FreqSetApply  = data;
//SpeedData[5]=data;
            gMainCmd.FreqPreWs     = data;
            gMainCmd.FreqSet       = data;
            gMainCmd.FreqFeed      = data;
            gMainCmd.FreqDesired   = data;

            gMainStatus.SubStep = 1;
            if (DCStart_flag == 1) {
#ifdef OPEN_LOOP_START
#ifdef FULL_OPEN_LOOP_MODE
                gMainStatus.RunStep = OPEN_ACC;
#else
                gMainStatus.RunStep = HALF_OPEN_ACC;
#endif
#else
                gMainStatus.RunStep = STATUS_RUN;
#endif
                gMainStatus.StatusWord.bit.SpeedSearchOver = 1;
//SpeedData[6]++;
            } else {
                if ((pm_est_lpf_omg1 > -SpinControlInternal) && (pm_est_lpf_omg1 < SpinControlInternal)) {
                    gMainStatus.RunStep = STATUS_BRAKE;
//SpeedData[7]++;
//SpeedData[8] = SpinControlInternal;
//SpeedData[9] = pm_est_lpf_omg1;
                } else {
                    // if (pm_est_lpf_omg1 <= (90000)) {
                    // if ((gMainCmd.FreqSetApply > 0) && (pm_est_lpf_omg1 < -90000) ||    //  56hz
                    //     (gMainCmd.FreqSetApply < 0) && (pm_est_lpf_omg1 >  90000)) {
                    ////////////////////////////////////////////////////////////////////////////////////////////
                    if (((frqAimTmp0 > 0) && (pm_est_lpf_omg1 < -SpinControlInternal)) ||    //  56hz
                        ((frqAimTmp0 < 0) && (pm_est_lpf_omg1 >  SpinControlInternal))) {
                        gMainStatus.RunStep = STATUS_BRAKE;
//SpeedData[10]++;
//SpeedData[11] = SpinControlInternal;
//SpeedData[12] = pm_est_lpf_omg1;
//SpeedData[13] = frqAimTmp0;
                    } else {
                        pm_integral_q = gBemf.OutVolt;
                        pm_integral_speed = ((long)OPEN_LOOP_TOR_START << 8);
                        if(gBemf.DIR == 1)
                        {
                            pm_integral_speed = -pm_integral_speed;
                        }
                        gMainStatus.RunStep = STATUS_RUN;//STATUS_PRE_RUN;//STATUS_RUN;
                        gMainStatus.StatusWord.bit.SpeedSearchOver = 1;
//SpeedData[14]++;
//SpeedData[15] = gMainCmd.FreqSetApply;
//SpeedData[16] = pm_est_lpf_omg1;
//SpeedData[17] = frqAimTmp0;
//SpeedData[18] = pm_ref_speed;
                    }
                }
            }

            if (gMainStatus.RunStep != STATUS_BRAKE) {
                EnableDrive();
            }
        }
        return;
	}
	else
	{
		gMainCmd.FreqSetApply  = 0;
		gMainCmd.FreqPreWs     = 0;
		gMainCmd.FreqSet       = 0;
		gMainCmd.FreqFeed      = 0;
		gMainCmd.FreqDesired   = 0;
		gMainStatus.StatusWord.bit.SpeedSearchOver = 1;
		gMainStatus.SubStep = 1;
		gMainStatus.RunStep = STATUS_RUN;
	}
}

//long AccRunData[10];
typedef enum {
    McInit              = 0,
    McAlignRun          = 1,
    McRsIDRun           = 2,
    McOpenRun           = 3,
    McSpdChangeToClosed = 4,
    McSFinished         = 5
} MCP_SPDSTATE_DEF;
MCP_SPDSTATE_DEF McSpdState;        // ȫ�ֱ�����STOP ������״̬�����������
static int McSpdStateCnt;           // ��ʱ�����֣�2MS ���ʱ�䵼�¹���û�н���ֱ���ƶ���OpenLoopAcc �ж�ֱ�ӽ���OpenAcc
int IDRef;int FrqTemp;
int RecordOpen;
void OpenLoopAccRun(void)
{
    if ((gMainStatus.ErrorCode != ERROR_NONE) || (gMainCmd.Command.bit.Start == FALSE))
    {
//AccRunData[0]++;
        DisableDrive();
        IDRef = 0;
        McSpdStateCnt = 0;
        McSpdState = McInit;
        gMainStatus.RunStep = STATUS_STOP;
        gMainStatus.SubStep = 1;
        return;
    }

    switch (McSpdState) {
    case McInit:
//AccRunData[1]++;
        if (pm_control_mode == 1) {
            McSpdState = McAlignRun;
        } else {
            gMainStatus.RunStep = STATUS_RUN;
        }
    break;
    case McAlignRun:
//AccRunData[2]++;
         if (gMainCmd.Command.bit.StartDC == 1)
         {
//AccRunData[3]++;
             gMainCmd.FreqPreWs    = 0;
             gMainCmd.FreqSetApply = 0;
             if (IDRef > DCBrakeCur) {
                 IDRef = DCBrakeCur;
             } else {
                 IDRef += 30;
             }
//GpioDataRegs.GPATOGGLE.bit.GPIO16  = 1; // ż����ɲ����ֱ���ƶ��ڼ�ȷʵû�н�������ط���
             // ����ɲ�������ֱ���ƶ�����û��Ӱ�쵼��ֱ���ƶ��ڼ��� ���ȱ��
             PaseShiftEnable = 1;
         } else {
//AccRunData[4]++;
             McSpdStateCnt++;
             if (McSpdStateCnt > 2) {
                 McSpdStateCnt = 0;
                 McSpdState = McOpenRun;
             }
         }
    break;
    case McRsIDRun:
//AccRunData[5]++;
    break;
    case McOpenRun:
        PaseShiftEnable = 1;
//AccRunData[6]++;
        if (gMainCmd.FreqReal > FRQ_OPEN_TO_CLOSE) { // 20HZ
            IDRef = pm_min_curr;
            McSpdState = McSpdChangeToClosed;
        } else {
            IDRef = DCBrakeCur;
        }
    break;
    case McSpdChangeToClosed: {
#ifdef FULL_OPEN_LOOP_MODE
        pmsvc_init();
        PMFluxWeakInit();
//AccRunData[8]++;
        //pm_coef_alfa = 170666;
        if (gMainCmd.FreqSetApply < 0) {
            pm_est_angel = (long)(gPhase.OutPhase + 16384) * 3217L >> 8;
        } else {
            pm_est_angel = (long)(gPhase.OutPhase - 16384) * 3217L >> 8;
        }
        pm_integral_d = 0;
        pm_integral_q = (long)1200 << 12;
        if (gMainCmd.FreqSetApply < 0) {
            pm_integral_q = -pm_integral_q;
        }
        gMainStatus.RunStep = STATUS_RUN;
        McSpdState = McInit;
        PaseShiftEnable = 1;

        // Frq = 10.0HZ, 160200 / 16 = 10200
#ifdef  FREQUENCY_CONTROL_01HZ
        FrqTemp = (long)gMainCmd.FreqReal / 10 + 200;
#else
        FrqTemp = (long)gMainCmd.FreqReal + 2000;
#endif
        if (gMainCmd.FreqSetApply < 0) {
            FrqTemp = -FrqTemp;
        }
        frqLine.curValue = FrqTemp;
        frqTmp = FrqTemp;
        pm_min_curr2 = 2000;
#else
        gMainStatus.RunStep = STATUS_RUN;
        McSpdState = McInit;
        pm_est_angel = (long)(gPhase.OutPhase - pm_dq_angle) * 3217L >> 8;

        // ����ջ���IQ ��ʼ����...
        pm_integral_speed = ((long)OPEN_LOOP_TOR_START << 8);
#endif
    }
    break;
    case McSFinished:
    break;
    }

    pm_ref_iq = 0;
    pm_ref_id = IDRef;
#if 0
if (RecordOpen == 1) {
ControlAllowRecord(1,1);
IsRecordThisSample(
        McSpdState,
        gMainStatus.RunStep,   // IV
        gMainCmd.FreqSetApply,
        runStatus,//gCurSamp.V,
        gMainCmd.Command.bit.StartDC,
        1,
        gPhase.OutPhase//gIAmpTheta.Theta//gPWM_CM
        );
}
#endif
}

int IDRef2;
/************************************************************
	�������й��̴���
	����״̬��, 2ms...
************************************************************/
long Iq = 0;
long Id = 0;
#pragma CODE_SECTION(RunCaseRun,"ramfuncs");
void RunCaseRun(void)
{
#if (SINGLE_SHUNT_PWM_MODE == NORMAL_NOISE_PWM_MODE)
    static unsigned int PhaseShiftHysteresis;
#endif
    if ((gMainStatus.ErrorCode != ERROR_NONE) || (gMainCmd.Command.bit.Start == FALSE))
    {
        DisableDrive();

        IDRef2 = 0;
        gMainStatus.RunStep = STATUS_STOP;
        gMainStatus.SubStep = 1;
        return;
    }

#if (SINGLE_SHUNT_PWM_MODE == NORMAL_NOISE_PWM_MODE)
    if (gMainCmd.FreqSetApply < 0) {
        PhaseShiftHysteresis = 3000;
    } else {
        PhaseShiftHysteresis = 400;
    }
    if (gMainCmd.FreqReal > FRQ_PWM_SHIFT_EN) {                 // 100HZ
        PaseShiftEnable = 1;
    } else if (gMainCmd.FreqReal > FRQ_OPEN_TO_CLOSE + PhaseShiftHysteresis) {
        PaseShiftEnable = 0;
    }
#endif

    if (pm_control_mode != 0)
    {
        if ((gMainCmd.Command.bit.StartDC == 1) ||
            (gMainCmd.Command.bit.StopDC  == 1))
        {
#ifndef OPEN_LOOP_START
           // 3100, 2ms, 50*2 = 100ms
           // 25 * 100ms = 2500
           if (IDRef2 > DCBrakeCur) {
               IDRef2 = DCBrakeCur;
           } else {
               IDRef2 += 80;
           }
           pm_ref_id = IDRef2;
           pm_ref_iq = 0;
#endif

           gMainCmd.FreqPreWs    = 0;
           gMainCmd.FreqSetApply = 0;
           return;
        }

        // Enable drive 200MS �ڣ�û��RUNCASE Iq = 0. ������...
        if ((pm_check_ip_flag == 0) && (DCStart_flag == 0)) {
            pm_ref_iq = Iq;
            pm_ref_id = Id;
        }
        return;
     }

	// VF mode only
	if (gMainCmd.Command.bit.StartDC == 0)
    {
		VFFreqCal();
		CalOutVotInVFStatus();
		gOutVolt.VoltApply = gOutVolt.Volt;

		if (gMainCmd.FreqSetApply != 0) {
			gMainCmd.FreqLast = gMainCmd.FreqSetApply;
		}
		if(gMainCmd.FreqLast > 0)		gOutVolt.VoltPhaseApply = 8192;
		else if(gMainCmd.FreqLast < 0)	gOutVolt.VoltPhaseApply = -8192;
	}
}


/************************************************************
    �ϵ�Եض�·�ж�
    Alpha ������������V W��
    HC    ������������U V������֮ǰ��U �����Եر���������ĳ�V�ࡣ
    ����V+�෢�������V�������С
************************************************************/
void RunCaseShortGnd(void)
{
    switch(gMainStatus.SubStep)
    {
        case 1:
            gShortGnd.Comper = SHORT_GND_PERIOD;
            gShortGnd.Flag = 0;
            gShortGnd.BaseUDC = gUDC.uDC;
            gShortGnd.ShortCur = 0;

            EALLOW;
            EPwm2Regs.TBPRD = SHORT_GND_PERIOD;
            EPwm2Regs.CMPA.half.CMPA = SHORT_GND_PERIOD - 1;
            EPwm2Regs.CMPB           = SHORT_GND_PERIOD - 1;
            EPwm3Regs.TBPRD = SHORT_GND_PERIOD;
            EPwm4Regs.TBPRD = SHORT_GND_PERIOD;

            //ǿ�ƹر�ĳЩ�ű�
            EPwm2Regs.AQCSFRC.all = 0x00;//4;
            EPwm3Regs.AQCSFRC.all = 0x05;
            EPwm4Regs.AQCSFRC.all = 0x05;

            EPwm2Regs.DBCTL.all = 0x0B;//0;
            EPwm3Regs.DBCTL.all = 0;
            EPwm4Regs.DBCTL.all = 0;
            EDIS;

            gMainStatus.SubStep = 2;
            break;

        case 2:
            gMainStatus.SubStep = 3;
            EnableDrive();
            break;
        case 3:
            if ((gShortGnd.Flag          != 0       ) ||
                (abs(gShortGnd.ShortCur) > 1000     )) //(30 * 32)) ||// 410*2 Ϊ��ֵ���������Ƶ�������10%�Ƚ�
            {
//RunCaseShortGndData[0]=gShortGnd.Flag;
//RunCaseShortGndData[1]++;
//RunCaseShortGndData[2]=gShortGnd.ShortCur;
//RunCaseShortGndData[3]=gShortGnd.BaseUDC;
//RunCaseShortGndData[4]=gUDC.uDC;
                // �ϵ�Եض�·����
                DisableDrive();
                gMainStatus.ErrorCode = ERROR_MOTOR_SHORT_TO_GND;
                gMainStatus.SubStep = 4;
                break;
            }
//RunCaseShortGndData[6]=gShortGnd.ShortCur;
            if (gShortGnd.Comper <= (SHORT_GND_PERIOD - (SHORT_GND_PERIOD / 5)))
            {
                gMainStatus.SubStep = 4;
//RunCaseShortGndData[5]++;
            }
            else
            {
                gShortGnd.Comper -= SHORT_GND_CMPR_INC;
                EALLOW;
                EPwm2Regs.CMPA.half.CMPA = gShortGnd.Comper;
                EPwm2Regs.CMPB           = gShortGnd.Comper;
                EDIS;
            }
            break;

        case 4:
            DisableDrive();

            EALLOW;
            EPwm2Regs.DBCTL.all = 0x000B;
            EPwm3Regs.DBCTL.all = 0x000B;
            EPwm4Regs.DBCTL.all = 0x000B;

            EPwm2Regs.AQCSFRC.all = 0x0;
            EPwm3Regs.AQCSFRC.all = 0x0;
            EPwm4Regs.AQCSFRC.all = 0x0;
            EDIS;

            gMainStatus.StatusWord.bit.ShortGndOver = 1;
            gMainStatus.RunStep = STATUS_STOP;
            gMainStatus.SubStep = 0;
            if (gMainStatus.ErrFlag.bit.OvCurFlag == 1)
            {
                gMainStatus.ErrFlag.bit.OvCurFlag = 0;
                EALLOW;
                EPwm2Regs.TZCLR.bit.INT = 1;
                EDIS;
            }
            break;

        default:
            break;
    }
}


void RunCaseBrakeLowBridge(void)
{
    static int BrakeLowBridgeState;
    static int BrakeLowBridgeStateCnt;
    enum {
        BRAKE_LOW_BRIGE_INIT,
        BRAKE_LOW_BRIGE_LOWON,
        BRAKE_LOW_BRIGE_CHECK,
        BRAKE_LOW_BRIGE_FINISH
    };
//CatchSpinData[11]++;
//CatchSpinData[17]=BrakeLowBridgeState;
    switch (BrakeLowBridgeState)
    {
    case BRAKE_LOW_BRIGE_INIT:
//CatchSpinData[12]++;
//GpioDataRegs.GPATOGGLE.bit.GPIO16  = 1;
        BrakeLowBridgeStateCnt = 0;
        BrakeLowBridgeState = BRAKE_LOW_BRIGE_LOWON;
    break;
    case BRAKE_LOW_BRIGE_LOWON:
        // GpioRegs.MCRA.all &= 0xF03F;
//CatchSpinData[13]++;
//GpioDataRegs.GPATOGGLE.bit.GPIO16  = 1;
        EnableDrive();

        EALLOW;
        // Turn on Low bridge
#ifndef CUT_DOWN_VER_HARDWARE
        EPwm2Regs.AQCSFRC.all = 0x06;
        EPwm3Regs.AQCSFRC.all = 0x06;
        EPwm4Regs.AQCSFRC.all = 0x06;
#else
        // 1001 --
        // 10   -- Forces a continuous high on output B
        // 01   -- Forces a continuous low on output A
        EPwm2Regs.AQCSFRC.all = 0x09;
        EPwm3Regs.AQCSFRC.all = 0x09;
        EPwm4Regs.AQCSFRC.all = 0x09;
#endif
        // Disable Dead time ... ...
        EPwm2Regs.DBCTL.all     = 0;
        EPwm3Regs.DBCTL.all     = 0;
        EPwm4Regs.DBCTL.all     = 0;
        EDIS;

        BrakeLowBridgeState = BRAKE_LOW_BRIGE_CHECK;
    break;
    case BRAKE_LOW_BRIGE_CHECK:
        // �жϵ�����С����ʱ���Թ̶���ʱ��ʽ 2ms, 1000 ~ 2s
        BrakeLowBridgeStateCnt++;
        if (BrakeLowBridgeStateCnt > 1500) {
            BrakeLowBridgeStateCnt = 0;
            BrakeLowBridgeState = BRAKE_LOW_BRIGE_FINISH;
//CatchSpinData[14]++;
            DisableDrive();
        }
    break;
    case BRAKE_LOW_BRIGE_FINISH:
//CatchSpinData[15]++;
        EnableDrive();

        EALLOW;
        EPwm2Regs.AQCSFRC.all = 0x00;
        EPwm3Regs.AQCSFRC.all = 0x00;
        EPwm4Regs.AQCSFRC.all = 0x00;

#ifndef CUT_DOWN_VER_HARDWARE
        EPwm2Regs.DBCTL.all = 0x0007;
        EPwm3Regs.DBCTL.all = 0x0007;
        EPwm4Regs.DBCTL.all = 0x0007;
#else
        EPwm2Regs.DBCTL.all = 0x000B;
        EPwm3Regs.DBCTL.all = 0x000B;
        EPwm4Regs.DBCTL.all = 0x000B;
#endif
        EDIS;

        pmsvc_init();
        PMFluxWeakInit();
        PrepareParForRun();
        DCStart_flag = 1;
#ifdef OPEN_LOOP_START
#ifdef FULL_OPEN_LOOP_MODE
        gMainStatus.RunStep = OPEN_ACC;
#else
        gMainStatus.RunStep = HALF_OPEN_ACC;
#endif
#else
        gMainStatus.RunStep = STATUS_RUN;
#endif
        BrakeLowBridgeState = BRAKE_LOW_BRIGE_INIT;
        gMainStatus.StatusWord.bit.SpeedSearchOver = 1;
    break;
    default:
//CatchSpinData[16]++;
    break;
    };
}

/************************************************************
	ͣ�����̴���
************************************************************/
//int VolOffset;
//int Adc_Temp_V1;
//int Adc_Temp_V2;
//int Adc_Temp_V3;
void RunCaseStop(void)
{
    // ���ˮ�ã�ת��׷�ٲ���Ҫ��Ϊ�˸����ȳ���ͳһ���ж���������һ�¡�����ˮ�ã�
    // ������AD�ڵ�ֵΪ155.....
    ////////////////////////////////////////////////////////////////////
    //    Adc_Temp_V1 = AdcResult.ADCRESULT4;
    //    Adc_Temp_V2 = AdcResult.ADCRESULT5;
    //    Adc_Temp_V3 = AdcResult.ADCRESULT6;
    //    VolOffset = (Adc_Temp_V1 + Adc_Temp_V2 + Adc_Temp_V3);
    ////////////////////////////////////////////////////////////
    DisableDrive();							//ͣ���������

	PrepareParForRun();
	pmsvc_init();
	PMFluxWeakInit();
	gMainStatus.SubStep = 1;
    McSpdState = McInit;    // MCOPEN ʱ��Ƿѹ����ûû�취���¿�ʼDC--OPENRUN

    if(gMainStatus.StatusWord.bit.RunEnable != 3)
	{
		return;								//�ȴ���Ư������
	}

#ifdef SHORT_GND_TEST
    if (VolOffset < 80) {
        if (gMainStatus.StatusWord.bit.ShortGndOver == 0)
        {
            gMainStatus.RunStep = STATUS_SHORT_GND;
            gMainStatus.SubStep = 1;
            return;
        }
    }
#else
    gMainStatus.StatusWord.bit.ShortGndOver = 1;
#endif

	/////////////////////////////////////////
	if(gMainCmd.Command.bit.TunePart == 1)	//�ж��Ƿ���Ҫ������ʶ
	{
		gMainStatus.RunStep = STATUS_GET_PAR;
		gMainStatus.SubStep = 1;		
		return;			
	}

	if ((gMainStatus.ErrorCode == ERROR_NONE) && (gMainCmd.Command.bit.Start == TRUE))
	{
		// ת�ٸ�����, Ŀǰ�̶�Ϊ��ģʽ����......
		// ע���߼��������ȿ�����PWM��200ms ����IPD��Ȼ����������.
		// ��������ֹ����������������ԭ�����...
		// ����ʱ���и������⣬��Ϊ��4066 ԭ��û�п�����ʱ�����û�е�4066 �����е�ƽ
		if (gMainCmd.Command.bit.SpeedSearch == TRUE)
		{
            // 272, / 16 = 17
            // ˮ��һ��û�з��綯�Ʋ������������Ҫȷ�ϸ�ֵ������
#ifdef SPIN_CONTROL_WITH_BEMF
            //if (VolOffset < BemfOffset) {
		    if (1) {
#else
            if (0) {
#endif
#ifdef OPEN_LOOP_START
#ifdef FULL_OPEN_LOOP_MODE
                gMainStatus.RunStep = OPEN_ACC;
#else
                gMainStatus.RunStep = HALF_OPEN_ACC;
#endif
                pm_check_ip_flag = 0;
                DCStart_flag = 1;
                gMainCmd.FreqSetApply  = 0;
                gMainCmd.FreqPreWs     = 0;
                gMainCmd.FreqSet       = 0;
                gMainCmd.FreqFeed      = 0;
                gMainCmd.FreqDesired   = 0;
                gMainStatus.StatusWord.bit.SpeedSearchOver = 1;
#else
#if MOTOR_CONTROL_MODE == MC_SENSORED_FOC
                pm_check_ip_flag = 0;
                DCStart_flag = 0;
                gMainCmd.FreqSetApply  = 0;
                gMainCmd.FreqPreWs     = 0;
                gMainCmd.FreqSet       = 0;
                gMainCmd.FreqFeed      = 0;
                gMainCmd.FreqDesired   = 0;
                gMainStatus.StatusWord.bit.SpeedSearchOver = 1;
                gMainStatus.RunStep = STATUS_RUN;
#else
                gMainStatus.RunStep = STATUS_SPEED_CHECK;
#endif
#endif
                EnableDrive();
            } else {
#ifdef SPIN_CONTROL_WITH_BEMF
                DisableDrive();
#else
                EnableDrive();
#endif
                gMainStatus.RunStep = STATUS_SPEED_CHECK;
            }
			gMainStatus.SubStep = 1;
		}
        else
        {
            gMainStatus.RunStep = STATUS_RUN;
            gMainStatus.SubStep = 1;
            EnableDrive();
        }
	}
}

/************************************************************
	�����������ǰ�����ݳ�ʼ��������Ϊ�������׼����ʼ����
	ͣ�����̱������㴦��...
************************************************************/
void PrepareParForRun(void)
{
	gMainCmd.FreqSetApply = 0;
	gMainCmd.FreqPreWs = 0;
	gMainCmd.FreqLast = 0;
	gMainCmd.FreqReal = 0;
	gMainCmd.SpeedFalg = 0x8000;
	
	gOutVolt.Volt = 0;
	gOutVolt.VoltApply = 0;
	IDRef = 0;
	IDRef2 = 0;

	if(gMainCmd.FreqDesired > 0)		//����Ŀ��Ƶ�ʷ���ȷ����ʼ��λ��
	{
		gOutVolt.VoltPhaseApply = 8192;
	} else {
		gOutVolt.VoltPhaseApply = -8192;
	}		
	gPhase.OutPhase = (int)(gPhase.IMPhase>>16) + gOutVolt.VoltPhaseApply;

	gRatio = 0;
	gCurSamp.U = 0;
	gCurSamp.V = 0;
	gCurSamp.W = 0;
	gCurSamp.UErr = 600;
	gCurSamp.VErr = 600;
	gIUVW.U = 0;
	gIUVW.V = 0;
	gIUVW.W = 0;
	gLineCur.CurPerShow = 0;
	gLineCur.CurBaseInv = 0;
	gLineCur.CurPer = 0;
	gLineCur.CurPerFilter = 0;
	gIMT.M = 0;
	gIMT.T = 0;

	gOvUdc.StepApply = 0;
    gOvUdc.LastStepApply = 0;
    gOvUdc.AccTimes = 0;

    gDCBrake.Time = 0;
    gDCBrake.PID.Total = 0;

	gMainStatus.StatusWord.all &= 0xFE6A;
    gIAmpTheta.ThetaFilter = gIAmpTheta.Theta;

	EALLOW;
#if (SINGLE_SHUNT_PWM_MODE == LOW_NOISE_PWM_MODE_2)
	EPwm2Regs.TBPRD = 2 * gPWM.gPWMPrdApply;
	EPwm3Regs.TBPRD = 2 * gPWM.gPWMPrdApply;
	EPwm4Regs.TBPRD = 2 * gPWM.gPWMPrdApply;
    EPwm5Regs.TBPRD = 2 * gPWM.gPWMPrdApply;
#else
    EPwm2Regs.TBPRD = gPWM.gPWMPrdApply;
    EPwm3Regs.TBPRD = gPWM.gPWMPrdApply;
    EPwm4Regs.TBPRD = gPWM.gPWMPrdApply;
    EPwm5Regs.TBPRD = gPWM.gPWMPrdApply;
#endif

	EPwm2Regs.CMPA.half.CMPA = gPWM.gPWMPrdApply/2;
	EPwm3Regs.CMPA.half.CMPA = gPWM.gPWMPrdApply/2;
	EPwm4Regs.CMPA.half.CMPA = gPWM.gPWMPrdApply/2;
    EPwm5Regs.CMPA.half.CMPA = gPWM.gPWMPrdApply/2;
    EPwm5Regs.CMPB = gPWM.gPWMPrdApply / 2;

    gPWM_CMP.U_CMP_U = EPwm2Regs.CMPA.half.CMPA;
    gPWM_CMP.U_CMP_V = EPwm2Regs.CMPA.half.CMPA;
    gPWM_CMP.U_CMP_W = EPwm2Regs.CMPA.half.CMPA;
    gPWM_CMP.D_CMP_U = EPwm2Regs.CMPA.half.CMPA;
    gPWM_CMP.D_CMP_V = EPwm2Regs.CMPA.half.CMPA;
    gPWM_CMP.D_CMP_W = EPwm2Regs.CMPA.half.CMPA;

    gPWM_CMP.T1CMP = 100;
    gPWM_CMP.T2CMP = 500;
    EPwm5Regs.CMPA.half.CMPA = gPWM_CMP.T1CMP;
    EPwm5Regs.CMPB = gPWM_CMP.T2CMP;

	EDIS;

    CURR_SAMPLE_DELAY   = MotorTestData4 - MotorTestData1;  // (T_SAMPLE - T_DELAY)
    MIN_SAMPLE_TIME     = MotorTestData4 + MotorTestData1;  // (T_SAMPLE + T_DELAY)
    TWO_MIN_SAMPLE_TIME = MIN_SAMPLE_TIME * 2;              // MIN_SAMPLE_TIME * 2;

    //    data =  (long)75000UL * OVER_SPEED_SCALING; // ����Ƶ��ϵ��.Max = 20000 * 120
    //    pm_fast_freq = (data * 16)/100;             // 384000
    //    ��ʼ��һ�Σ�����  gBasePar.MaxFreq û�г�ʼ��... ...
    long data;
    data =  (long)gBasePar.MaxFreq * OVER_SPEED_SCALING;
#ifdef FREQUENCY_CONTROL_01HZ
    pm_fast_freq = (data * 16) / 10;
#else
    pm_fast_freq = (data * 16) / 100;
#endif
}

/************************************************************
	������Ư����
	4066�����Բ���һֱ��ȡ, main2ms call
************************************************************/
#if (CURRENT_SAMPLE_TYPE == CURRENT_SAMPLE_1SHUNT)
void GetCurrentExcursion(void)
{
    int m_ErrIv,m_ErrUu,m_ErrIbus;
	if((gMainStatus.RunStep    != STATUS_LOW_POWER) &&
	   (gMainStatus.RunStep    != STATUS_STOP     ))
	{
		gExcursionInfo.EnableCount = 0;
		return;
	}

	gExcursionInfo.EnableCount++;
	gExcursionInfo.EnableCount = (gExcursionInfo.EnableCount>200) ? 200 : gExcursionInfo.EnableCount;
	if ((gExcursionInfo.EnableCount < 200))
	{
		gExcursionInfo.TotalUu = 0;
		gExcursionInfo.TotalIv = 0;
		gExcursionInfo.TotalIbus= 0;
		gExcursionInfo.Count = 0;
		return;
	}

	// 4066: one time
	// speed check: bit = 3
    //	if ((IsCurExcursionFinshied == 1) && (IsRelayCheckFinshed == 1)) {
    //		gMainStatus.StatusWord.bit.RunEnable = 3;
    //		return;
    //	}
	//////////////////////////////////////////////////////////////////////
	gExcursionInfo.TotalIv += (int)ADC_IV;
	gExcursionInfo.TotalUu += (int)ADCRESULT_UU;
	gExcursionInfo.TotalIbus += (int)ADC_IBUS;
	gExcursionInfo.Count++;

	if (gExcursionInfo.Count >= 32)
	{
		m_ErrIv = gExcursionInfo.TotalIv >> 5;
        if (-32768 == m_ErrIv) {
            m_ErrIv = -32767;
        }
        m_ErrUu = gExcursionInfo.TotalUu >> 5;
        if (-32768 == m_ErrUu) {
            m_ErrUu = -32767;
        }
        m_ErrIbus = gExcursionInfo.TotalIbus >>5;
        if (-32768 == m_ErrIbus) {
            m_ErrIbus = -32767;
        }

        gExcursionInfo.TotalIv = 0;
		gExcursionInfo.TotalUu = 0;
		gExcursionInfo.TotalIbus = 0;
		gExcursionInfo.Count = 0;

		gMainStatus.StatusWord.bit.RunEnable = 3;
		if ((abs(m_ErrIv-2048) < 500) && (1))   // ��ѹ�жϣ���
		{
		    gExcursionInfo.ErrUu = m_ErrUu;
			gExcursionInfo.ErrIv = m_ErrIv;
			gExcursionInfo.ErrIbus = m_ErrIbus;
			gExcursionInfo.ErrCnt = 0;
		} else {
			gMainStatus.ErrorCode = ERROR_CURRENT_SAMPLE;
			gExcursionInfo.ErrCnt = 0;
			gExcursionInfo.EnableCount = 0;
		}
	}
}
#else
void GetCurrentExcursion(void)
{
    int m_ErrIu,m_ErrIv,m_ErrIw;
    if((gMainStatus.RunStep    != STATUS_LOW_POWER) &&
       (gMainStatus.RunStep    != STATUS_STOP     ))
    {
        gExcursionInfo.EnableCount = 0;
        return;
    }

    gExcursionInfo.EnableCount++;
    gExcursionInfo.EnableCount = (gExcursionInfo.EnableCount>200) ? 200 : gExcursionInfo.EnableCount;
    if ((gExcursionInfo.EnableCount < 200))
    {
        gExcursionInfo.TotalIu = 0;
        gExcursionInfo.TotalIv = 0;
        gExcursionInfo.TotalIw = 0;
        gExcursionInfo.Count = 0;
        return;
    }

    // 4066: one time
    // speed check: bit = 3
    //  if ((IsCurExcursionFinshied == 1) && (IsRelayCheckFinshed == 1)) {
    //      gMainStatus.StatusWord.bit.RunEnable = 3;
    //      return;
    //  }
    /////////////////////////////////////////////////////////////////////

    gExcursionInfo.TotalIu += (int)(ADC_IU - (Uint)32768);
    gExcursionInfo.TotalIv += (int)(ADC_IV - (Uint)32768);
    gExcursionInfo.TotalIw += (int)(ADC_IW - (Uint)32768);
    gExcursionInfo.Count++;

    if (gExcursionInfo.Count >= 32)
    {
        m_ErrIu = gExcursionInfo.TotalIu >> 5;
        m_ErrIv = gExcursionInfo.TotalIv >> 5;
        m_ErrIw = gExcursionInfo.TotalIw >> 5;
        if (-32768 == m_ErrIu) {
            m_ErrIu = -32767;
        }
        if (-32768 == m_ErrIv) {
            m_ErrIv = -32767;
        }
        if (-32768 == m_ErrIw) {
            m_ErrIw = -32767;
        }
        gExcursionInfo.TotalIu = 0;
        gExcursionInfo.TotalIv = 0;
        gExcursionInfo.TotalIw = 0;
        gExcursionInfo.Count = 0;

        gMainStatus.StatusWord.bit.RunEnable = 3;
        //if ((abs(m_ErrIu) < 5120) && (abs(m_ErrIv) < 5120) && (abs(m_ErrIw) < 5120))
        if ((abs(m_ErrIu) < 5120) && (abs(m_ErrIv) < 5120))// && (abs(m_ErrIw) < 5120))
        {
            gExcursionInfo.ErrIu = m_ErrIu;
            gExcursionInfo.ErrIv = m_ErrIv;
            gExcursionInfo.ErrIw = m_ErrIw;
            gExcursionInfo.ErrCnt = 0;
        } else {
            gMainStatus.ErrorCode = ERROR_CURRENT_SAMPLE;
            gExcursionInfo.ErrCnt = 0;
            gExcursionInfo.EnableCount = 0;
        }
    }
}
#endif

/*************************************************************
**************************************************************
�����жϣ����ģ�����������������㡢VC���������ƵȲ���
**************************************************************
*************************************************************/
#pragma CODE_SECTION(ADCOverInterrupt, "ramfuncs");
void ADCOverInterrupt()
{
	if ((pm_control_mode  == 0) &&
	    (pm_check_ip_flag == 0) &&
	    (DCStart_flag == 0))
	{
		ADCProcess();
#if (CURRENT_SAMPLE_TYPE == CURRENT_SAMPLE_1SHUNT)
		SVPWM_1ShuntGetPhaseCurrent();
#else
		SVPWM_3ShuntGetPhaseCurrent();
#endif

   		GetUDCInfo();
		// GetAIInfo();
		ChangeCurrent();

   		CalRatioFromVot();
   		CalDeadBandComp();

        CalOutputPhase();
        OutPutPWMVF();
#ifdef LOW_NOISE_PWM_MODE
        OutPutPWMPhaseShiftForLowNoiseFullMode();
#else
        OutPutPWMPhaseShift();
#endif
        UpdatPWMRegs();
	} else {
	    MotorControlISR();
	}
}

/*************************************************************
	���PWM������ʹ�ز����ں������λ��Ч
*************************************************************/
void SoftPWMProcess(void)
{
    // ��ͬ�����¿��ܰڶ��ķ�Χ������
}

/*************************************************************
	�����жϴ������򣨿������жϣ���ƽ������
*************************************************************/
void HardWareErrorDeal()
{
	// DisableDrive();

	gMainStatus.ErrFlag.bit.OvCurFlag = 1;
	if (gMainStatus.RunStep == STATUS_SHORT_GND) {
	    gShortGnd.Flag = 1;                     //�ϵ�Եض�·
	} else if(gMainStatus.ErrorCode != ERROR_OC_HARDWARE) {
		gMainStatus.ErrorCode = ERROR_OC_HARDWARE;
	}
	EALLOW;
	EPwm2Regs.TZCLR.bit.OST = 1;
	EPwm3Regs.TZCLR.bit.OST = 1;
	EPwm4Regs.TZCLR.bit.OST = 1;

    // EPWM.PDF TI, Page 64
    // The TZFLG[DCAEVT1/2] or TZFLG[DCBEVT1/2] flag bit will remain set until it is manually
    // cleared by writing to the TZCLR[DCAEVT1/2] or TZCLR[DCBEVT1/2] bit. If the DC trip event is still
    // present when the TZFLG[DCAEVT1/2] or TZFLG[DCBEVT1/2] flag is cleared, then it will again be
    // immediately set
    EPwm2Regs.TZCLR.bit.DCAEVT1 = 1;
    EPwm3Regs.TZCLR.bit.DCAEVT1 = 1;
    EPwm4Regs.TZCLR.bit.DCAEVT1 = 1;
	EDIS;
}

/*************************************************************
	�������ϴ���
*************************************************************/
void SoftWareErrorDeal(void)					
{
	static int SoftwareOCCnt;

	// Ƿѹ״̬�²��ж���������
	if ((gMainStatus.RunStep   == STATUS_LOW_POWER        ) ||
	    (gMainStatus.ErrorCode == ERROR_MOTOR_SHORT_TO_GND))
	{
		gUDC.uDCBigFilter = gUDC.uDCFilter;
		return;										
	}
	if (gMainStatus.LastErrorCode != gMainStatus.ErrorCode )
	{
	    gMainStatus.LastErrorCode = gMainStatus.ErrorCode;

		// ���ϸ�λ�����нǶȷ����仯 
        if (ERROR_NONE != gMainStatus.ErrorCode) {
			gPhase.IMPhase += 0x40000000L;
		}				           
    }

	// ��ʼ���ϸ�λ
	if (gMainCmd.Command.bit.ErrorOK == 1) 			
	{
		gMainStatus.ErrorCode = ERROR_NONE;
		if (gMainStatus.ErrFlag.bit.OvCurFlag == 1)
		{
			gMainStatus.ErrFlag.bit.OvCurFlag = 0;

			EALLOW;
			EPwm2Regs.TZCLR.bit.OST = 1;
			EPwm3Regs.TZCLR.bit.OST = 1;
			EPwm4Regs.TZCLR.bit.OST = 1;
			EPwm2Regs.TZCLR.bit.INT = 1;

            // EPWM.PDF TI, Page 64
            // The TZFLG[DCAEVT1/2] or TZFLG[DCBEVT1/2] flag bit will remain set until it is manually
            // cleared by writing to the TZCLR[DCAEVT1/2] or TZCLR[DCBEVT1/2] bit. If the DC trip event is still
            // present when the TZFLG[DCAEVT1/2] or TZFLG[DCBEVT1/2] flag is cleared, then it will again be
            // immediately set
            /////////////////////////////////////////////////////////////////////////////////////////////////////
            EPwm2Regs.TZCLR.bit.DCAEVT1 = 1;
            EPwm3Regs.TZCLR.bit.DCAEVT1 = 1;
            EPwm4Regs.TZCLR.bit.DCAEVT1 = 1;
			EDIS;
		}
	}

	/////////////////////////////////////////////////��ʼ�ж���������
	// ��������ʵ�����岻�󣬵��͵���һ�ر������Ѱ�.��Ӳ����ͬ�Ĺ�����...
	// if ((gLineCur.CurBaseInv 		 > SOFT_OC_POINT) &&
	// 	(gMainCmd.Command.bit.Start == TRUE		 ))
	// {
	// 	SoftwareOCCnt++;
	// 	if (SoftwareOCCnt >= 10) {
	// 		SoftwareOCCnt = 0;
	// 		DisableDrive();
	// 		gMainStatus.ErrorCode = ERROR_OC_SOFTWARE;
	// 		gLineCur.ErrorShow = gLineCur.CurPer;
	// 	}
	// } else {
	//     if (SoftwareOCCnt > 1) SoftwareOCCnt--;
	// }

	// if (gUDC.uDC > gInvInfo.InvUpUDC)	        //��ѹ�ж�,ʹ�ô��˲���ѹ
	// {
	// 	DisableDrive();
	// 	gMainStatus.ErrorCode = ERROR_OV_ACC_SPEED;
	// }
	// else if (gUDC.uDC < gInvInfo.InvLowUDC)   //Ƿѹ�ж�,ʹ�ô��˲���ѹ
	// {
	// 	DisableDrive();
	// 	DisConnectRelay();
	// 	gMainStatus.RunStep = STATUS_LOW_POWER;
	// 	gMainStatus.SubStep = 0;
	// 	gMainStatus.ErrorCode = ERROR_UV;
    //     gMainStatus.StatusWord.bit.LowUDC = 1;
	// }

	// if (gMainCmd.Command.bit.Start != TRUE)
	// {
	// 	SoftwareOCCnt = 0;
	// }

    /*
	// ERROR_STALL ����
	static int InstallCnt2;
    if ((pm_ref_speed           > 80000                     ) &&    // Ref > 50Hz,
        (pm_est_omg             < 60000                     ) &&    // omg < 37Hz,
        (gMainStatus.ErrorCode != ERROR_LOSE_PHASE_OUTPUT   ) &&
        (gMainCmd.Command.bit.StartDC               != 1    ) &&
        (pm_ref_iq              > (LimitHGlobal - 50        ))) {
        InstallCnt2++;
        if (InstallCnt2 > 250) {
            InstallCnt2 = 0;
//            DisableDrive();
//            gMainStatus.ErrorCode = ERROR_STALL;
        }
    } else {
        if (InstallCnt2 > 0)  InstallCnt2 -= 5;
    }
    */

    // ���ټ�⣬�ٶȳ�������
    // һ�������
    // 1��û�ӵ�����ٶȹ۲�ֵ���ԡ�
    // 2������PI ̫С������ʱ���ٶȳ���̫�ࡣ���������ѹ�����أ������������ܻᣩ
    // ��������������Ρ�
    // static int InstallCnt1;
    // if (pm_fast_freq != 0)
    // {
    //     if ((pm_est_omg > pm_fast_freq) || (pm_est_omg < -pm_fast_freq))
    //     {
    //         InstallCnt1++;
    //         if (InstallCnt1 > 5) {
    //             DisableDrive();
    //             gMainStatus.ErrorCode = ERROR_ERROR_KE;
    //         } else {
    //             InstallCnt1 = 0;
    //         }
    //     }
    // }

    /*
    // ���ձ������ٶȴﵽһ��ֵ�Ҹ��غ�С�����������һ��ʱ�䡣����
    ////////////////////////////////////////////////////////
    static int InstallCnt3;
    if ((pm_ref_speed                   > 130000) &&     // Ref > 80Hz,
        (pm_est_omg                     > 130000) &&     // omg > 80Hz,
        ((gLineCur.CurPerFilter >> 5)   < 800   ) &&     // 1 / 5 �ֵ
        (gLineCur.CurPer                > 120   ) &&     // ���˵�����ǿ�ת. ���ӵ��ƽ��50����
        (gMainCmd.Command.bit.StartDC  != 1     )) {
        InstallCnt3++;
        if (InstallCnt3 > 1000) {
            InstallCnt3 = 0;
            //DisableDrive();
            //gMainStatus.ErrorCode = ERROR_NO_LOAD;
        }
    } else {
        if (InstallCnt3 > 0)  InstallCnt3 -= 3;
    }
    */

}

/*************************************************************
	ʸ�����ƵĹ�ѹ���ƹ��ܣ�ͨ��ĸ�ߵ�ѹ�������ת��(����ת��)�����ֵ
*************************************************************/
void CalUdcLimitIT(void)
{
    static int LowToruqeCurLimit = 0;
    int m_Udc;
    m_Udc = gUDC.uDC;

    gVFPar.ovGain = OVER_DC_VOL_KP;
    if (gVFPar.ovGain != 0)
    {
        gUdcLimitIt.UDCBakCnt++;
        if(gUdcLimitIt.UDCBakCnt >= 5)
        {
            gUdcLimitIt.UDCBakCnt = 0;
            gUdcLimitIt.UDCDeta = m_Udc - gUdcLimitIt.UDCBak;
            gUdcLimitIt.UDCBak = m_Udc;
            if(gUdcLimitIt.UDCDeta < 200)
            {
                gUdcLimitIt.UDCDeta = 0;
            }
        }
        if(m_Udc < (gOvUdc.Limit - gUdcLimitIt.UDCDeta))
        {
            gUdcLimitIt.UdcPid.Total = (long)-gIMT.T<<16;
            gUdcLimitIt.UDCLimit = pm_curr_limitH;
        }
        else if((m_Udc < gOvUdc.Limit) && (gUdcLimitIt.FirstOvUdcFlag == 0))
        {
            //��һ�ν����ѹΣ���������ز������Ӽ���
            gUdcLimitIt.FirstOvUdcFlag = 1;
            gUdcLimitIt.UDCLimit = gUdcLimitIt.UdcPid.Total>>16;
        }
        else
        {
            gUdcLimitIt.UdcPid.KP = 10000;
            gUdcLimitIt.UdcPid.KI = 2000;
            gUdcLimitIt.UdcPid.KD = 0;
            gUdcLimitIt.UdcPid.QP = 0;
            gUdcLimitIt.UdcPid.QI = 0;
            gUdcLimitIt.UdcPid.Max = pm_curr_limitH;
            gUdcLimitIt.UdcPid.Min = LowToruqeCurLimit;

            if (1) {
                if (m_Udc > MaxAllowUdcLimit) {
                    if (gUdcLimitIt.FirstOvUdcFlag2 == 0) {
                        gUdcLimitIt.FirstOvUdcFlag2 = 1;
                        gUdcLimitIt.UdcPid.Total = 0;
                    }
                    LowToruqeCurLimit = -(pm_curr_limitH >> 1);
                } else if ((m_Udc > MidAllowUdcLimit) && (gUdcLimitIt.UdcPid.Total > 0)) {
                    gUdcLimitIt.FirstOvUdcFlag2 = 1;
                    gUdcLimitIt.UdcPid.Total = 0;
                } else {
                    LowToruqeCurLimit = 0;
                    if (m_Udc < gOvUdc.Limit) {
                        gUdcLimitIt.FirstOvUdcFlag2 = 0;
                    }
                }
            } else {
                LowToruqeCurLimit = 0;
                gUdcLimitIt.FirstOvUdcFlag2 = 0;
            }

            gUdcLimitIt.UdcPid.Deta = gOvUdc.Limit - m_Udc;
            PID2((PID_STRUCT_2 *) &gUdcLimitIt.UdcPid);
            gUdcLimitIt.UDCLimit = gUdcLimitIt.UdcPid.Out>>16;
        }
    }
    else
    {
        if (pm_forbid_revtorq == 1) {
            gUdcLimitIt.UDCLimit = 0;
        } else {
            gUdcLimitIt.UDCLimit = pm_curr_limitH;// >> 1;;
        }
        gUdcLimitIt.UdcPid.Total = 0;
        gUdcLimitIt.FirstOvUdcFlag = 0;
    }
}

#pragma CODE_SECTION(calc_out_angle2,"ramfuncs");
void calc_out_angle2()
{
    long data;
    unsigned int data1;

    if ((gMainCmd.Command.bit.StartDC == 1) ||
        (gMainCmd.Command.bit.StopDC  == 1)) /****���ƶ�״̬****/
    {
        // Range: 0 ~ 65535
        data1 = gPhase.IMPhase;//�������Ƕ� + 110 * 65535 / 360������
    }
    else
    {
        data1 = encoder.elec_degree;//�������Ƕ� + 110 * 65535 / 360������
    }

    data = data1 + pm_dq_angle;
    if (data > 65535L) {
        data = data - 65535L;
    }
    if (data < 0) {
        data = data + 65535L;
    }

    gPhase.IMPhase = (unsigned long)data1 * (unsigned long)65535;
    gPhase.OutPhase = data;
}

#pragma CODE_SECTION(MotorControlISR, "ramfuncs");
void MotorControlISR()
{
#ifdef SPIN_CONTROL_WITH_BEMF
    GetBemf_DirSpeed();
#endif
#if (CURRENT_SAMPLE_TYPE == CURRENT_SAMPLE_1SHUNT)
    SVPWM_1ShuntGetPhaseCurrent();
#else
    SVPWM_3ShuntGetPhaseCurrent();
#endif
    ChangeCurrent();

    // {
    //     // �Ե����ز�����iq��id����һ�׵�ͨ�˲�����
    //     static int32_t M_q20 = 0, T_q20 = 0;
        
    //     M_q20 += (((int32_t)gIMT.M << 20) - M_q20) >> 1;
    //     T_q20 += (((int32_t)gIMT.T << 20) - T_q20) >> 1;

    //     gIMT.M = (int16_t)((M_q20 + (1 << 19)) >> 20);
    //     gIMT.T = (int16_t)((T_q20 + (1 << 19)) >> 20);
    // }

    if (gMainCmd.Command.bit.Start == TRUE)
    {
        // pm_check_ip_flag = PE.18 �����Ƿ����ʼλ��...
        // ʹ�ܺ󣬿�ʼ���λ�ã�Ȼ�󽫸�λ�� 0��
        if ((gMainCmd.Command.bit.StartDC == 1) ||
            (gMainCmd.Command.bit.StopDC  == 1)) /****���ƶ�״̬****/
        {
            // OutPhase -32767 ~ 32767, that is -180 ~ 180degree.
            // 60degree ~ 10922...
            if (gMainCmd.Command.bit.SecondDCPhase == 1) {
                gPhase.OutPhase = 10922;
            } else {
                gPhase.OutPhase = 0;
            }
            gPhase.IMPhase = 0;

            // pm_est_angel = (long)gPhase.OutPhase * 3217L >> 8;
            // pm_est_angel = (long)(gPhase.OutPhase + 16384) * 3217L >> 8;
            pm_est_angel = (long)(gPhase.OutPhase + 1) * 3217L >> 8;
            if (pm_est_angel < 0) {
                pm_est_angel += 823549;
            }
        }
        if (pm_check_ip_flag == 0) {
#if MOTOR_CONTROL_MODE == MC_SENSORED_FOC
            // Speed feedback removed - speed loop not needed
#else
            FluxPostionCalation();
#endif
            CurrentLoop();
            VolVectCalation();
            CalRatioFromVot();
#if MOTOR_CONTROL_MODE == MC_SENSORED_FOC
            calc_out_angle2();
#else
            VolAngleCalation();
#endif
            CalDeadBandComp();
            OutPutPWMVF();
#if (CURRENT_SAMPLE_TYPE == CURRENT_SAMPLE_1SHUNT)
            OutPutPWMPhaseShiftForLowNoiseFullMode();
#endif
            UpdatPWMRegs();
        } else {
            SynInitPosDetect();
        }
    } else {
        RunBoostState = 0;
        ResetIndex();
        //        RecordEnable = 0;
    }

//    CBCLimitCurPrepare();                   //��������������
#if 0
static int RecordEnable;
//if (gMainCmd.Command.bit.Start == 1 && gMainCmd.Command.bit.StartDC == 1) {
if (runTimeTicker >= 499) {
    RecordEnable = 1;
}
if (RecordEnable == 1) {// && gMainCmd.Command.bit.Start == 1) {
ControlAllowRecord(1,1);    // 1ms * 128 = 128ms
IsRecordThisSample(
        pm_ref_id,
        pm_ref_iq,
        gCurSamp.W,
        gRatio,//gPWM.U,//gPWM.U,//AdcResult.ADCRESULT3,   // IU
        gLineCur.CurPer,//
        gPhase.OutPhase,
        gDCBrake.PID.Total >> 16//
        );
}
#endif
#if 0
static int EnableRecord;
if (gMainCmd.FreqReal >= 1838) {
    EnableRecord = 1;
}
if (EnableRecord == 1) {
ControlAllowRecord(1,10);
IsRecordThisSample(
        pm_ref_id,
        pm_ref_iq,
        pm_dq_angle,//pm_est_angel,   // IV
        gCurSamp.W,//pm_est_bem,//pm_uq,//
        pm_ref_speed >> 4,//pm_dq_angle,
        pm_est_omg >> 4,//gCurSamp.W,
        gPhase.OutPhase//gIAmpTheta.Theta//gPWM_CM
        );
}
#endif

}


void ChangeCurrent_2ms(void)
{
    Ulong   m_Long;
    long m_Long1;
    long m_Long2;

    //  m_Long = (((long)gIAlphBeta.Alph * (long)gIAlphBeta.Alph) +
    //            ((long)gIAlphBeta.Beta * (long)gIAlphBeta.Beta));
    m_Long1 = gIAlphBeta.Alph;
    m_Long1 *= m_Long1;
    m_Long2 = gIAlphBeta.Beta;
    m_Long2 *= m_Long2;
    m_Long = m_Long1 + m_Long2;

    gIAmpTheta.Amp = (Uint)qsqrt(m_Long);
    gLineCur.CurPer = (gIAmpTheta.Amp>>1) + (gLineCur.CurPer>>1);
    gLineCur.CurPerFilter += gLineCur.CurPer - (gLineCur.CurPerFilter>>5);

    m_Long = (Ulong)gLineCur.CurPer * (Ulong)gMotorInfo.Current;
    gLineCur.CurBaseInv = m_Long/gInvInfo.InvCurrent;
    gLineCur.CurBaseInvFilter += gLineCur.CurBaseInv - (gLineCur.CurBaseInvFilter>>9);
    OutputLoseAdd();

#if 0
    // output power calculation here
    ////////////////////////////////
    {
        // ������ָ���ʱ����������Temp �ǳ���...
        signed short TorqueCurAbs;
        TorqueCurAbs = gIMT.T;
        if (TorqueCurAbs < 0) {
            TorqueCurAbs = -TorqueCurAbs;
        }

        // add 128 as min flux current
        TorqueCurAbs += 128;

        m_Temp = (long)TorqueCurAbs * 200 >> 12;        // 100��~ 1.00A
        m_Temp *= 220;                                  // 100 * 220 = 220w(22000)
        m_Temp = (long)m_Temp * gRatio >> 12;           // Ratio, 2048..
        m_Temp /= 100;
        Power = m_Temp;
        m_TempAcc = ((((long)Power << 16) - m_TempAcc) >> 5) + m_TempAcc;
        Power  = (m_TempAcc + 0x8000) >> 16;
        gUDC.Power = Power;
    }
#endif
}

void AllowSelectBottomOnly(unsigned short Selection)
{
    EALLOW;
    switch (Selection) {
        case 0:                         // U_BOTTOM_ONLY
#ifndef CUT_DOWN_VER_HARDWARE
            EPwm2Regs.AQCSFRC.all = 0x06;
            EPwm3Regs.AQCSFRC.all = 0x0A;
            EPwm4Regs.AQCSFRC.all = 0x0A;
#else
            // B3 B2 -- CSFB
            // B1 B0 -- CSFA
            // 00 -- Force Disable
            // 01 -- Low
            // 10 -- High
            // 11 -- Disabled and No effect
            EPwm2Regs.AQCSFRC.all = 0x09;
            EPwm3Regs.AQCSFRC.all = 0x05;
            EPwm4Regs.AQCSFRC.all = 0x05;
            EPwm2Regs.DBCTL.all     = 0;
            EPwm3Regs.DBCTL.all     = 0;
            EPwm4Regs.DBCTL.all     = 0;
#endif
        break;
        case 1:                         // V_BOTTOM_ONLY
#ifndef CUT_DOWN_VER_HARDWARE
            EPwm2Regs.AQCSFRC.all = 0x0A;
            EPwm3Regs.AQCSFRC.all = 0x06;
            EPwm4Regs.AQCSFRC.all = 0x0A;
#else
            EPwm2Regs.AQCSFRC.all = 0x05;
            EPwm3Regs.AQCSFRC.all = 0x09;
            EPwm4Regs.AQCSFRC.all = 0x05;
            EPwm2Regs.DBCTL.all     = 0;
            EPwm3Regs.DBCTL.all     = 0;
            EPwm4Regs.DBCTL.all     = 0;
#endif
        break;
        case 2:                         // W_BOTTOM_ONLY
#ifndef CUT_DOWN_VER_HARDWARE
            EPwm2Regs.AQCSFRC.all = 0x0A;
            EPwm3Regs.AQCSFRC.all = 0x0A;
            EPwm4Regs.AQCSFRC.all = 0x06;
#else
            EPwm2Regs.AQCSFRC.all = 0x05;
            EPwm3Regs.AQCSFRC.all = 0x05;
            EPwm4Regs.AQCSFRC.all = 0x09;
            EPwm2Regs.DBCTL.all     = 0;
            EPwm3Regs.DBCTL.all     = 0;
            EPwm4Regs.DBCTL.all     = 0;
#endif
        break;
        case 3:                         // Normal PWM Pattern
            EPwm2Regs.AQCSFRC.all = 0x00;
            EPwm3Regs.AQCSFRC.all = 0x00;
            EPwm4Regs.AQCSFRC.all = 0x00;
#ifndef CUT_DOWN_VER_HARDWARE
            EPwm2Regs.DBCTL.all = 0x0007;
            EPwm3Regs.DBCTL.all = 0x0007;
            EPwm4Regs.DBCTL.all = 0x0007;
#else
            EPwm2Regs.DBCTL.all = 0x000B;
            EPwm3Regs.DBCTL.all = 0x000B;
            EPwm4Regs.DBCTL.all = 0x000B;
#endif
        break;
        case 4:                         // Normal PWM Pattern
#ifndef CUT_DOWN_VER_HARDWARE
            EPwm2Regs.AQCSFRC.all = 0x0A;
            EPwm3Regs.AQCSFRC.all = 0x0A;
            EPwm4Regs.AQCSFRC.all = 0x0A;
#else
            EPwm2Regs.AQCSFRC.all = 0x05;
            EPwm3Regs.AQCSFRC.all = 0x05;
            EPwm4Regs.AQCSFRC.all = 0x05;
#endif
            EPwm2Regs.DBCTL.all     = 0;
            EPwm3Regs.DBCTL.all     = 0;
            EPwm4Regs.DBCTL.all     = 0;
        break;
        default:
        break;
    }
    EDIS;
}
