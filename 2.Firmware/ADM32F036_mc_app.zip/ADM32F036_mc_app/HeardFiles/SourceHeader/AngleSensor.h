/*
 * AngleSensor.h
 *
 *  Created on: 2025��6��25��
 *      Author: advancechip
 */

#ifndef HEARDFILES_SOURCEHEADER_ANGLESENSOR_H_
#define HEARDFILES_SOURCEHEADER_ANGLESENSOR_H_


typedef struct
{
    long    AdcSinN;
    long    AdcSinP;
    long    AdcCosN;
    long    AdcCosP;
    long    MrSin_Calib;//��׼ֵ
    long    MrCos_Calib;//��׼ֵ
    long    MrSin;//������ʵʱ�ź�
    long    MrCos;//������ʵʱ�ź�
    Uint    InitElecDegree;//У׼��Ƕ�
    Uint    ElecDegree;//������Ƕ�
    Uint    MachDegree;//������е�Ƕ�
    Uint    MotorPairs;
    Uint    MotorPowerOnFlag;

}DEGREE_STRUCT;

typedef struct
{
    long  PLL_P;
    long  PLL_I;
    Uint  PLL_Theta;
    long  PLL_OMG;
    long  PLL_OMG_filter;
    long  PLL_freq;
    long  PLL_error;
    long  PLL_cos;
    long  PLL_sin;
    long  PLL_intgerator;
}PLL_STRUCT;
extern PLL_STRUCT    PLL_Sensors;
extern DEGREE_STRUCT Degree;

void AngleCal(void);

#endif /* HEARDFILES_SOURCEHEADER_ANGLESENSOR_H_ */
