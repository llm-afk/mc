
#ifndef __F_PARAMETER_H__
#define __F_PARAMETER_H__

extern unsigned long MAX_PEAK_CUR_3_3V_410;
extern unsigned long MAX_PEAK_CUR_3_3V_2;
extern unsigned int MAX_DC_VOL_3_3V;

extern unsigned int OVER_DC_VOL_POINT;
extern unsigned int OVER_DC_VOL_LIMIT;
extern unsigned int UNDER_DC_VOL_POINT;
extern unsigned int  OVER_DC_VOL_KP;
extern unsigned int MaxAllowUdcLimit;
extern unsigned int MidAllowUdcLimit;

extern unsigned int OverCurPointInternal;   // Ӳ�������Ƚ�ֵ
extern unsigned int CBCCurPointInternal;    // CBC�����Ƚ�ֵ

extern unsigned int DeadTimeInternal;
extern unsigned int DeadTimeCompInternal;

///////////////////////////////////////////////////////////////////////////////////////
// �����������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int MOTOR_RATED_POWER;    //0.1WΪ��λ
extern unsigned int MOTOR_RATED_VOL;
extern unsigned int MOTOR_RATED_CUR;
extern unsigned int LOWER_LIMIT_FREQ;

extern unsigned int PMSM_LD;          // 37uH
extern unsigned int PMSM_LQ;          // 50uH
extern unsigned int PMSM_RS;          // 11mohm
extern unsigned int PMS_L_R_UNIT;           //
#ifdef KE_WIDE_RANGE
extern unsigned int PMSM_KE;          // Ke = 43
#else
extern unsigned int PMSM_KE;           // ke = 4
#endif

///////////////////////////////////////////////////////////////////////////////////////
// �����л��ջ���������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int FRQ_OPEN_TO_CLOSE;    // Ҫ����һ�µ�λ������0.01HZ
//extern unsigned int FULL_OPEN_LOOP_MODE;       // ����ģʽ����ֹ���θ���
extern unsigned int OPEN_LOOP_TOR_START;
extern unsigned int FRQ_PWM_SHIFT_EN;   // Ҫ����һ�µ�λ������0.01HZ

///////////////////////////////////////////////////////////////////////////////////////
// �ٶȻ���������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int F_CHANGING_POINT_1_PI;
extern unsigned int F_CHANGING_POINT_2_PI;
extern unsigned int LOW_SPEED_KI;
extern unsigned int LOW_SPEED_KP;
extern unsigned int HIGH_SPEED_KI_GAIN;
extern unsigned int HIGH_SPEED_KP_GAIN;

///////////////////////////////////////////////////////////////////////////////////////
// ���Ʋ�������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int PWM_FREQUENCY;     // 100 * 0.1kHz �ز�Ƶ��
extern unsigned int AVR_MODE;

///////////////////////////////////////////////////////////////////////////////////////
// ����������������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int D_CUR_KI;
extern unsigned int D_CUR_KP;
extern unsigned int Q_CUR_KI;
extern unsigned int Q_CUR_KP;


//--------------------- Ƶ�ʷ�Χ����----------------------/
extern unsigned int MAX_LIMIT_FREQ;   // 300.00Hz
extern unsigned int MOTOR_RATED_FRE;
extern unsigned int COAST_STOP_FRQ;    // 1.0HZ,����ͣ����ʼƵ��

//--------------------- ֱ���ƶ�����----------------------/
extern unsigned int DC_CONTROL_KP;
extern unsigned int DC_CONTROL_KI;
extern unsigned int DC_BRAKE_CUR;

extern unsigned int TORQUE_CUR_LIMIT;

extern long SpinControlInternal;

extern unsigned int FILED_WEEKING_MODE;         // FE-00, 0 ~ 2
extern unsigned int FILED_WEEKING_CUR_SCAL;     // FE-01, 0 ~ 200
extern unsigned int FILED_WEEKING_SCAL;         // FE-02, 1 ~ 10
extern unsigned int FIELD_WEAK_REF;             // FE-05, 0 ~ 4100
extern unsigned int IPD_PERIOD_SCALING;         // ���������������ر�С�������е����ܴ�
extern unsigned int SOFT_OC_POINT;              // Current limit : 3A,150%
extern unsigned int IdMaxScaling;               // ���ŵ���ռ�������ٷֱȣ�512 ����50%��Q10 ��ʽ
extern unsigned int IqMaxSet;                   // NOT USED

extern unsigned int STALL_PR_TIME;              // 8s, 8000ms

extern unsigned int OVER_SPEED_SCALING;
extern unsigned int SPEED_FEEDBACK_FILTER;
extern unsigned int SF_LOW_SPEED;
extern unsigned int MIN_CUR_LOW_SPEED;
extern unsigned int FILED_WEEKING_OUTVOL_SC;
extern unsigned int SPECIAL_FACTOR_1;
extern unsigned int SPEED_MEASURE_PAR_1;
extern unsigned int SPEED_MEASURE_PAR_2;
extern unsigned int START_PRESET_CUR;
extern unsigned int LOW_LIMIT_FREQUENCY;
extern unsigned int INIT_POS_DECTION_MODE;
extern unsigned int INIT_POS_DECTION_CUR;
extern unsigned int INIT_POS_DECTION_TIME;
extern unsigned int LOW_SPEED_FILTER;
extern unsigned int PMSM_RS_MIN;

extern unsigned int T_DELAY;
extern unsigned int T_SAMPLE;
extern unsigned int FirstSamplePointShift;
extern unsigned int SecondSamplePointShift;

extern unsigned int LowLimit;
extern unsigned int HighLimit;
extern unsigned int BemfOffset;

extern int RefSet;
extern unsigned int ACC1;
extern unsigned int ACC2;
extern unsigned int DCBrakeTime;
extern unsigned int AUTO_RESET_CNT;
extern unsigned int ThetaCoff;
extern unsigned int AVR_Mode;

extern unsigned int RatioForLowNoisePWM;
extern unsigned int RatiotThresholdForLowNoisePWM;

#define CURRENT_SAMPLE_TYPE             CURRENT_SAMPLE_2SHUNT
#define SINGLE_SHUNT_PWM_MODE           NORMAL_NOISE_PWM_MODE//LOW_NOISE_PWM_MODE // LOW_NOISE_PWM_MODE_2 // NORMAL_NOISE_PWM_MODE //
#define ADM32F036_TYPE                  ADM32F036_A2
//#define SPI_SCOPE_TEST                  1

// ���ϻָ�ʱ������
#define VOLT_FAULT_RECOVER_TIME        (2000)
#define CURRENT_FAULT_RECOVER_TIME     (2000)
#define STALL_FAULT_RECOVER_TIME       (2000)
#define PHASELOSS_FAULT_RECOVER_TIME   (8000)
#define TEMP_FAULT_RECOVER_TIME        (2000)
#define START_FAULT_RECOVER_TIME       (1000)
#define EMPTY_FAULT_RECOVER_TIME       (2000)

#define YellowLED_ON                GpioDataRegs.GPASET.bit.GPIO18  = 1
#define YellowLED_OFF               GpioDataRegs.GPACLEAR.bit.GPIO18    = 1

#define TRIP_FLASHING_TIME          100
#define WAIT_POWER_ON_TIME          10000       // ����������֮�󣬵ȴ�_*0.5ms��ʼ��ӦǷѹ��������������

#define LD_LQ_BASED_ON_CUR          1
extern int MTPA_Ld_TableData_H[20];
extern int MTPA_Lq_TableData_H[20];

#endif // __F_PARAMETER_H__

