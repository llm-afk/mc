/*
 * Lin_Communication.h
 *
 *  Created on: 2024��11��25��
 *      Author: Administrator
 */

#ifndef HEARDFILES_SOURCEHEADER_LIN_COMMUNICATION_H_
#define HEARDFILES_SOURCEHEADER_LIN_COMMUNICATION_H_

#include "Define.h"
#include "ADP32F03x_Device.h"

/*Linͨ�Žṹ�嶨��*/
typedef struct Lin_Communication
{
    /*������������*/
    Uint32 EcwpSpdReq;             //����ٶ�����
    Uint32 EcwpSafeMode;           //ģʽ����
    Uint32 EcwpEna;                //���ʹ��
    /*������������*/
    Uint32 EcwpActSpd;             //����ٶ�
    Uint32 EcwpLoVolt;             //���ӵ�ѹ
    Uint32 EcwpBdT;                //�����¶�
    Uint32 EcwpActCur;             //�������
    Uint32 EcwpOverCurErr;         //��������
    Uint32 EcwpDryRunErr;          //��ת����
    Uint32 EcwpVoltErr;            //��ѹ����
    Uint32 EcwpBlkErr;             //��ת����
    Uint32 EcwpTempErr;            //���¶ȹ���
    Uint32 EcwpRespErr;            //ͨ�Ź���
}Lin_COMMUNICATION;


struct LINTD0 {                // bit    description
    Uint16  TD3:8;             // 7:0    Transmit Buffer 3
    Uint16  TD2:8;             // 15:8   Transmit Buffer 2
    Uint16  TD1:8;             // 23:16  Transmit Buffer 1
    Uint16  TD0:8;             // 31:24  Transmit Buffer 0
};


typedef union LIN_data0 {
   Uint32         all;
   struct LINTD0  bit;
} LIN_DATA0;


struct LINTD1 {                // bit    description
    Uint16  TD7:8;             // 7:0    Transmit Buffer 7
    Uint16  TD6:8;             // 15:8   Transmit Buffer 6
    Uint16  TD5:8;             // 23:16  Transmit Buffer 5
    Uint16  TD4:8;             // 31:24  Transmit Buffer 4
};

typedef union LIN_data1 {
   Uint32          all;
   struct LINTD1   bit;
} LIN_DATA1;

extern Lin_COMMUNICATION Lin_Communication;

extern void UpdateRecivedLinDataToVars(void);
extern void UpdateLinDataToSent(void);
extern void UpdateLinDataToVar(void);

extern unsigned short GetSetupFreComs(void);
extern unsigned short GetStartCMDComs(void);

extern Uint16 ReciveDataIDCorrect[8];
extern Uint16 ReciveDataIDInCorrect[8];
extern LIN_DATA0 SenddDataA;
extern LIN_DATA1 SenddDataB;

#endif /* HEARDFILES_SOURCEHEADER_LIN_COMMUNICATION_H_ */
