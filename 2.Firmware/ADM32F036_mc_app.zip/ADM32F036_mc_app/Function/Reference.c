
#include "Define.h"
#include "Reference.h"
#include "Main.h"
#include "RunSrc.h"
#include "Parameter.h"
#include "LinLDF.h"
#include "MotorInclude.h"

int32 frq;              // ˲ʱֵ, ���ܴ��ݸ����ܵ�����Ƶ��
int32 frqTmp;           // ����frq����ʱ����
int32 frqAim;           // �趨(Ŀ��)Ƶ��
int32 frqAimTmp;        // ����frqAim����ʱ����, ��һ�μ��㲻��ʹ�á���ԾƵ��֮�󣬵㶯Ƶ��֮ǰ��
int32 frqAimTmp0;       // ����frqAim����ʱ����, ��һ�μ����ʹ�á�Ƶ��Դ�趨֮����ԾƵ��֮ǰ��
int32 frqCurAim;        // ��ǰĿ��Ƶ�ʣ�ע����ÿ�ε���AccDecFrqCalc()֮ǰҪ����frqCurAim

Uint32 upperFrq;        // ����Ƶ��
Uint16 lowerFrq;        // ����Ƶ��
Uint32 maxFrq;          // ���Ƶ��
Uint16 upperTorque;     // �ٶȿ���ʱΪת�����ޣ�ת�ؿ���ʱΪ�趨ת��
long   SpeedRefAcc;

Uint16 MaxRPM_SET = 7000;
Uint16 MinRPM_SET = 50;

void UpdateLimitFrq(void);
void TorqueCalc(void);

extern long pm_est_omg;
extern long pm_ref_speed;
volatile int RefSet2 = 1700;
unsigned int FrqTest[20];
void FrqSrcDeal(void)
{
	// ������Ƶ�ʼ���
    UpdateLimitFrq();

	// ת�����޼���
    TorqueCalc();

	// Ƶ��Դ����
    if (1) {
    	frqAimTmp0 = RefSet;//GetSetupFreComs();
    } else {
    	unsigned int FreqSet = AdcResult.ADCRESULT3;
    	static unsigned long FreqSetFilter = 0;
    	static unsigned long FreTemp;

    	FreqSetFilter = FreqSetFilter - (FreqSetFilter >> 5) + (FreqSet >> 5);

    	FreTemp = ((unsigned long)FreqSetFilter * upperFrq) >> 12;
    	FreTemp = ((unsigned long)FreTemp * 4140) >> 12;

    	if (FreTemp > upperFrq) {
    		FreTemp = upperFrq;
    	} else if (FreTemp < lowerFrq) {
    		FreTemp = lowerFrq;
    	}
    	frqAimTmp0 = FreTemp;
    }

    {
        // ���ÿһ�����У������ǵ�һ���ϵ�... ...
        static long Counter;
        static long Counter1s;

        // Ref 2ms level.
        if (runFlag.bit.common) {
            Counter++;
            if (Counter == 500) {
                if (Counter1s < 5000) {
                    Counter1s ++;
                }
                Counter = 0;
            }
        } else {
            Counter1s = 0;
            Counter = 0;
        }
#ifndef OPEN_LOOP_START
        if (Counter1s < 2) {
            SetAccTimes(ACC1);
        } else {
            SetAccTimes(ACC2);
        }
#else
        if (gMainStatus.RunStep == OPEN_ACC || gMainStatus.RunStep == HALF_OPEN_ACC) {
            SetAccTimes(ACC1);
        } else {
            SetAccTimes(ACC2);
        }
#endif
    }


    // �ж��Ƿ񳬹�����Ƶ��
    if (frqAimTmp0 > (int32)upperFrq) {
        frqAimTmp0 = (int32)upperFrq;
    } else if (frqAimTmp0 < -(int32)upperFrq) {
        frqAimTmp0 = -(int32)upperFrq;
	}

	// ��ֵ��frqAimTmp
    frqAimTmp = frqAimTmp0;
}
void UpdateFrqSetAim(void)
{
	// ���з���
    if (FORWARD_DIR != runCmd.bit.dir) {
        frqAimTmp = -frqAimTmp;
    }   
	// �ж��Ƿ񳬹�����Ƶ��
    if ((frqAimTmp > upperFrq)&&(frqAimTmp > 0)) {
        frqAimTmp = upperFrq;
    } else if (frqAimTmp < -(int32)upperFrq) {
        frqAimTmp = -(int32)upperFrq;
	}
	// ��ֵ��frqAim
    frqAim = frqAimTmp;
}

//extern unsigned long IbusActual;
//unsigned long ActualPower = 0;
long PoeError,PoePout,PoeIout,PoePIout,IntegralPoe;
unsigned int PowerCoff = 2540;
void POE_Limit(long PowerValve,long PowerKp,long PowerKi)
{
#if 0
    static unsigned int FilterRatio;
    static long FilterRatioAcc;

    static unsigned int FilterOutVolt;
    static long FilterOutVoltAcc;

    static unsigned int FilterOutCur;
    static long FilterOutCurAcc;

    FilterOutVoltAcc  += ((((long)outVoltage << 16) - FilterOutVoltAcc) >> 6);
    FilterOutVolt = (FilterOutVoltAcc + 0x8000) >> 16;

    FilterOutCurAcc  += ((((long)outCurrent << 16) - FilterOutCurAcc) >> 6);
    FilterOutCur = (FilterOutCurAcc + 0x8000) >> 16;

    FilterRatio = ((long)FilterOutVolt * generatrixVoltage)/ 310;
    FilterRatio = (long)FilterRatio * 380 >> 12;
    FilterRatio = (long)FilterRatio * FilterOutCur >> 11;
    //FilterRatio = (long)FilterRatio * 502 >> 10;
    FilterRatio = (long)FilterRatio * PowerCoff >> 10;

    FilterRatioAcc  += ((((long)FilterRatio << 16) - FilterRatioAcc) >> 6);
    FilterRatio = (FilterRatioAcc + 0x8000) >> 16;

    ActualPower = FilterRatio;
    PoeError = ActualPower - PowerValve;
    PoeIout = PoeError * PowerKi;
    PoePout = PoeError * PowerKp;
    IntegralPoe += (PoeIout>>6);
    if(IntegralPoe >= 32000)
       IntegralPoe = 32000;
    else if(IntegralPoe <= -32000)
       IntegralPoe = -32000;
    PoePIout = (PoePout>>6) + (IntegralPoe>>5);
    if(PoePIout >= 1000)
       PoePIout =  1000;
    else if(PoePIout <= -1000)
       PoePIout =  -1000;
    //frqAimTmp0 -= PoePIout
#else
    ActualPower = (long)gUDC.uDCFilter * IbusActual;
    ActualPower = ActualPower/100;//0.1W

    PoeError = PowerValve -ActualPower;
    //PoeError = ActualPower - PowerValve;
    PoeIout = (PoeError * PowerKi);
    PoePout = (PoeError * PowerKp);
    IntegralPoe += (PoeIout>>6);

    if(IntegralPoe >= 384000)
       IntegralPoe = 384000;
    else if(IntegralPoe <= 0)
       IntegralPoe = -0;

    PoePIout = (PoePout>>6) + (IntegralPoe>>5);
    if(PoePIout >= 12000)
       PoePIout =  12000;
    else if(PoePIout <= 0)
       PoePIout =  0;
   // frqAimTmp0 -= PoePIout;
    //pm_ref_iq = PoePIout;

#endif

}

void TorqueCalc(void)
{
#if 0
    int TorqueSet;
    if (generatrixVoltage > 3000) {
        TorqueSet = 10240;
    } else if (generatrixVoltage < 2600) {
        TorqueSet = 8000;
    } else {
        // TorqueSet = ((long)(generatrixVoltage - 2600) * 224) / 400;
        TorqueSet = ((long)(generatrixVoltage - 2600) * 5730) >> 10;
        TorqueSet += 8000;
        if (TorqueSet > 10240) {
            TorqueSet = 10240;
        } else if (TorqueSet < 8000) {
            TorqueSet = 8000;
        }
    }
    TorqueSet = ((long)TorqueSet * TorqueLimitSet) >> 10;
    static long TorqueSetAcc = 1024UL << 16;
    TorqueSetAcc = ((((int32)TorqueSet << 16) - TorqueSetAcc) >> 5) + TorqueSetAcc;
    TorqueSet  = (TorqueSetAcc + 0x8000) >> 16;

	upperTorque = TorqueSet;
#else
    // 110V����ʱ����ֵ��
    upperTorque = TORQUE_CUR_LIMIT * 10;
#endif
}

void UpdateLimitFrq(void)
{
    maxFrq = MAX_LIMIT_FREQ;
    upperFrq = MAX_LIMIT_FREQ;
    lowerFrq = LOWER_LIMIT_FREQ;
}
